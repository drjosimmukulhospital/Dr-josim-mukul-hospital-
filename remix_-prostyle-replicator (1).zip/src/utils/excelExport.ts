/**
 * Exports data to Excel format (.xls) with UTF-8 BOM support.
 */
export function exportToExcel(filename: string, tableHtml: string) {
  const uri = 'data:application/vnd.ms-excel;base64,';
  const template = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="UTF-8">
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Sheet1</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
<style>
  table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
  th, td { border: 1px solid #999999; padding: 8px; text-align: left; }
  th { background-color: #0f766e; color: white; font-weight: bold; }
  .text-right { text-align: right; }
  .text-center { text-align: center; }
  .header-title { font-size: 18pt; font-weight: bold; color: #0f766e; }
  .header-sub { font-size: 11pt; color: #555555; }
</style>
</head>
<body>
${tableHtml}
</body>
</html>`;

  const base64 = (s: string) => window.btoa(unescape(encodeURIComponent(s)));

  const link = document.createElement('a');
  link.href = uri + base64(template);
  link.download = filename.endsWith('.xls') ? filename : `${filename}.xls`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportTransactionsToExcel(hospitalName: string, address: string, phone: string, transactions: any[]) {
  let rows = '';
  let totalIncome = 0;
  let totalExpense = 0;

  transactions.forEach((t, index) => {
    const isIncome = t.type === 'Income';
    if (isIncome) totalIncome += t.amount;
    else totalExpense += t.amount;

    rows += `
      <tr>
        <td class="text-center">${index + 1}</td>
        <td>${new Date(t.date).toLocaleDateString()}</td>
        <td><span style="color: ${isIncome ? '#059669' : '#dc2626'}; font-weight: bold;">${t.type}</span></td>
        <td>${t.category}</td>
        <td>${t.description}</td>
        <td class="text-right">${isIncome ? t.amount.toLocaleString() + ' BDT' : '-'}</td>
        <td class="text-right">${!isIncome ? t.amount.toLocaleString() + ' BDT' : '-'}</td>
      </tr>
    `;
  });

  const netBalance = totalIncome - totalExpense;

  const html = `
    <div style="text-align: center; margin-bottom: 20px;">
      <div class="header-title">${hospitalName}</div>
      <div class="header-sub">${address} | Phone: ${phone}</div>
      <h3 style="margin-top: 10px; color: #333;">Hospital & Diagnostic Financial Ledger Statement</h3>
      <p style="font-size: 9pt;">Report Generated Date: ${new Date().toLocaleString()}</p>
    </div>
    <table>
      <thead>
        <tr>
          <th>Sl. No</th>
          <th>Date</th>
          <th>Type</th>
          <th>Category</th>
          <th>Description</th>
          <th class="text-right">Income (BDT)</th>
          <th class="text-right">Expense (BDT)</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
      </tbody>
      <tfoot>
        <tr style="background-color: #f3f4f6; font-weight: bold;">
          <td colspan="5" class="text-right">Total:</td>
          <td class="text-right" style="color: #059669;">${totalIncome.toLocaleString()} BDT</td>
          <td class="text-right" style="color: #dc2626;">${totalExpense.toLocaleString()} BDT</td>
        </tr>
        <tr style="background-color: #e0f2fe; font-size: 13pt; font-weight: bold;">
          <td colspan="5" class="text-right">Net Account Balance:</td>
          <td colspan="2" class="text-center" style="color: ${netBalance >= 0 ? '#0284c7' : '#dc2626'};">
            ${netBalance.toLocaleString()} BDT (${netBalance >= 0 ? 'Surplus' : 'Deficit'})
          </td>
        </tr>
      </tfoot>
    </table>
  `;

  exportToExcel(`${hospitalName}_Financial_Ledger_${new Date().toISOString().split('T')[0]}`, html);
}
