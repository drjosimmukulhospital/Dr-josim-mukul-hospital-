export interface HospitalInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
  slogan?: string;
}

export interface DiagnosticTest {
  id: string;
  code: string;
  name: string;
  category: 'Pathology' | 'Radiology' | 'Cardiology' | 'Ultrasound' | 'Biochemistry' | 'Others';
  price: number;
  normalRange?: string;
  roomNo?: string;
}

export interface Doctor {
  id: string;
  name: string;
  degree: string;
  specialty: string;
  phone: string;
  commissionRate: number; // e.g. 30 for 30%
}

export interface BillTestItem {
  testId: string;
  code: string;
  name: string;
  price: number;
  discount: number; // absolute amount or calculated
}

export interface PatientBill {
  id: string;
  receiptNo: string;
  patientName: string;
  age: string;
  gender: 'Male' | 'Female' | 'Child' | 'Others';
  phone: string;
  refDoctorId: string;
  refDoctorName: string;
  tests: BillTestItem[];
  subTotal: number;
  discountAmount: number;
  netTotal: number;
  paidAmount: number;
  dueAmount: number;
  paymentMethod: 'Cash' | 'Card' | 'Mobile Banking';
  date: string; // ISO string
  deliveryDate: string;
  status: 'Paid' | 'Due' | 'Refunded';
}

export interface Bed {
  id: string;
  name: string;
  type: 'General Ward' | 'Cabin (Non-AC)' | 'Cabin (AC)' | 'ICU' | 'CCU';
  dailyRate: number;
  isOccupied: boolean;
  currentPatientName?: string;
  currentPatientId?: string;
}

export interface AdmittedPatient {
  id: string;
  regNo: string;
  patientName: string;
  age: string;
  gender: 'Male' | 'Female' | 'Child';
  phone: string;
  guardianName: string;
  address: string;
  admittingDoctor: string;
  bedId: string;
  bedName: string;
  bedType: string;
  dailyRate: number;
  admissionDate: string; // ISO string
  dischargeDate?: string;
  status: 'Admitted' | 'Discharged';
  advancePaid: number;
  serviceCharges: number;
  medicineCharges: number;
  doctorVisitCharges: number;
  discount: number;
  totalBillComputed?: number;
  netPaid?: number;
}

export interface AccountTransaction {
  id: string;
  date: string;
  type: 'Income' | 'Expense';
  category: 'Diagnostic Bill' | 'Hospital Bill' | 'Pharmacy' | 'Salary & Allowance' | 'Utility Bill' | 'Doctor Commission' | 'Other Expenses';
  description: string;
  amount: number;
  refId?: string;
}
