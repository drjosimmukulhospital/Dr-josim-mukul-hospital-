import React, { useState, useEffect, useRef } from 'react';
import { HospitalInfo, DiagnosticTest, Doctor, PatientBill, Bed, AdmittedPatient, AccountTransaction } from './types';
import { initialHospitalInfo, initialTests, initialDoctors, initialBills, initialBeds, initialAdmissions, initialTransactions } from './data/initialData';
import { Navbar } from './components/Navbar';
import { DiagnosticBillingView } from './components/DiagnosticBillingView';
import { HospitalManagementView } from './components/HospitalManagementView';
import { AccountsDashboardView } from './components/AccountsDashboardView';
import { SettingsSecurityView } from './components/SettingsSecurityView';
import { AdminLockScreen } from './components/AdminLockScreen';
import { exportToExcel } from './utils/excelExport';
import { ToastNotification, ToastItem } from './components/ToastNotification';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<'billing' | 'hospital' | 'accounts' | 'settings'>('billing');

  // Toasts State
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const isMounted = useRef(false);

  const addToast = (message: string) => {
    setToasts((prev) => [...prev, { id: `${Date.now()}-${Math.random()}`, message }]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  // Admin Security Pin State
  const [savedPin, setSavedPin] = useState<string>(() => localStorage.getItem('erp_admin_pin') || '1234');
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(false);
  const [showAdminPinModal, setShowAdminPinModal] = useState<boolean>(false);

  // Core Data Stores
  const [hospitalInfo, setHospitalInfo] = useState<HospitalInfo>(() => {
    const s = localStorage.getItem('erp_hinfo');
    return s ? JSON.parse(s) : initialHospitalInfo;
  });

  const [tests, setTests] = useState<DiagnosticTest[]>(() => {
    const s = localStorage.getItem('erp_tests');
    return s ? JSON.parse(s) : initialTests;
  });

  const [doctors, setDoctors] = useState<Doctor[]>(() => {
    const s = localStorage.getItem('erp_doctors');
    return s ? JSON.parse(s) : initialDoctors;
  });

  const [bills, setBills] = useState<PatientBill[]>(() => {
    const s = localStorage.getItem('erp_bills');
    return s ? JSON.parse(s) : initialBills;
  });

  const [beds, setBeds] = useState<Bed[]>(() => {
    const s = localStorage.getItem('erp_beds');
    return s ? JSON.parse(s) : initialBeds;
  });

  const [admissions, setAdmissions] = useState<AdmittedPatient[]>(() => {
    const s = localStorage.getItem('erp_admissions');
    return s ? JSON.parse(s) : initialAdmissions;
  });

  const [transactions, setTransactions] = useState<AccountTransaction[]>(() => {
    const s = localStorage.getItem('erp_txs');
    return s ? JSON.parse(s) : initialTransactions;
  });

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('erp_admin_pin', savedPin);
    if (isMounted.current) {
      addToast('Admin Security PIN has been updated successfully.');
    }
  }, [savedPin]);

  useEffect(() => {
    localStorage.setItem('erp_hinfo', JSON.stringify(hospitalInfo));
    if (isMounted.current) {
      addToast('Hospital profile settings and receipt header information saved.');
    }
  }, [hospitalInfo]);

  useEffect(() => {
    localStorage.setItem('erp_tests', JSON.stringify(tests));
    if (isMounted.current) {
      addToast('Diagnostic investigation tests directory updated.');
    }
  }, [tests]);

  useEffect(() => {
    localStorage.setItem('erp_doctors', JSON.stringify(doctors));
    if (isMounted.current) {
      addToast('Referral partner doctors list and commission rates saved.');
    }
  }, [doctors]);

  useEffect(() => {
    localStorage.setItem('erp_bills', JSON.stringify(bills));
    if (isMounted.current) {
      addToast('Patient diagnostic billing invoice records saved.');
    }
  }, [bills]);

  useEffect(() => {
    localStorage.setItem('erp_beds', JSON.stringify(beds));
    if (isMounted.current) {
      addToast('Hospital cabin and ward bed allocation layouts updated.');
    }
  }, [beds]);

  useEffect(() => {
    localStorage.setItem('erp_admissions', JSON.stringify(admissions));
    if (isMounted.current) {
      addToast('In-patient admission logs and register synced.');
    }
  }, [admissions]);

  useEffect(() => {
    localStorage.setItem('erp_txs', JSON.stringify(transactions));
    if (isMounted.current) {
      addToast('Financial ledger accounting transaction records synchronized.');
    }
  }, [transactions]);

  // Handlers
  const handleAddBill = (newBill: PatientBill) => {
    setBills((prev) => [newBill, ...prev]);
    // Also auto-log transaction for income
    if (newBill.paidAmount > 0) {
      const newTx: AccountTransaction = {
        id: `tx-bill-${Date.now()}`,
        date: newBill.date,
        type: 'Income',
        category: 'Diagnostic Bill',
        description: `Invoice ${newBill.receiptNo} Payment Received (${newBill.patientName})`,
        amount: newBill.paidAmount,
        refId: newBill.id,
      };
      setTransactions((prev) => [newTx, ...prev]);
    }
  };

  const handleAdmitPatient = (newAdmit: AdmittedPatient, bedId: string) => {
    setAdmissions((prev) => [newAdmit, ...prev]);
    setBeds((prev) =>
      prev.map((b) =>
        b.id === bedId
          ? { ...b, isOccupied: true, currentPatientName: newAdmit.patientName, currentPatientId: newAdmit.id }
          : b
      )
    );

    // Auto-log advance deposit transaction
    if (newAdmit.advancePaid > 0) {
      const newTx: AccountTransaction = {
        id: `tx-adm-${Date.now()}`,
        date: newAdmit.admissionDate,
        type: 'Income',
        category: 'Hospital Bill',
        description: `Patient ${newAdmit.patientName} (${newAdmit.regNo}) Admission Advance Deposit`,
        amount: newAdmit.advancePaid,
        refId: newAdmit.id,
      };
      setTransactions((prev) => [newTx, ...prev]);
    }
  };

  const handleDischargePatient = (patientId: string, finalBillAmount: number) => {
    const patient = admissions.find((a) => a.id === patientId);
    if (!patient) return;

    const netCollected = Math.max(0, finalBillAmount - patient.advancePaid);

    setAdmissions((prev) =>
      prev.map((a) =>
        a.id === patientId ? { ...a, status: 'Discharged', dischargeDate: new Date().toISOString() } : a
      )
    );

    setBeds((prev) =>
      prev.map((b) => (b.currentPatientId === patientId ? { ...b, isOccupied: false, currentPatientName: undefined, currentPatientId: undefined } : b))
    );

    if (netCollected > 0) {
      const newTx: AccountTransaction = {
        id: `tx-dis-${Date.now()}`,
        date: new Date().toISOString(),
        type: 'Income',
        category: 'Hospital Bill',
        description: `Patient ${patient.patientName} final discharge bill payment`,
        amount: netCollected,
        refId: patientId,
      };
      setTransactions((prev) => [newTx, ...prev]);
    }
    alert('Patient successfully discharged and bed vacated!');
  };

  const handleAddTransaction = (newTx: AccountTransaction) => {
    setTransactions((prev) => [newTx, ...prev]);
  };

  // Master Global Excel Export (.xls) containing all sheets/data
  const handleMasterExcelExport = () => {
    let html = `
      <div style="text-align: center; margin-bottom: 25px; font-family: sans-serif;">
        <h1 style="color: #047857; margin-bottom: 5px;">${hospitalInfo.name}</h1>
        <p style="color: #4b5563; margin: 2px;">${hospitalInfo.address}</p>
        <p style="color: #4b5563; margin: 2px;">Phone: ${hospitalInfo.phone} | Email: ${hospitalInfo.email}</p>
        <h2 style="background-color: #065f46; color: white; padding: 10px; margin-top: 20px;">Hospital & Diagnostic Complete ERP Master Database Report</h2>
        <p style="font-size: 11px; color: #6b7280;">Exported At: ${new Date().toLocaleString()}</p>
      </div>
    `;

    // 1. Transactions Sheet
    html += `<h3 style="color: #065f46; border-bottom: 2px solid #065f46; padding-bottom: 4px;">1. Income-Expense Transaction Ledger</h3>`;
    html += `<table border="1" cellspacing="0" cellpadding="6">
      <thead style="background-color: #047857; color: white;">
        <tr><th>Sl No.</th><th>Date</th><th>Type</th><th>Category</th><th>Description</th><th>Amount</th></tr>
      </thead><tbody>`;
    transactions.forEach((t, i) => {
      html += `<tr><td align="center">${i + 1}</td><td>${new Date(t.date).toLocaleDateString()}</td><td style="color:${t.type==='Income'?'#059669':'#dc2626'};font-weight:bold;">${t.type}</td><td>${t.category}</td><td>${t.description}</td><td align="right">${t.amount} BDT</td></tr>`;
    });
    html += `</tbody></table><br/><br/>`;

    // 2. Bills Sheet
    html += `<h3 style="color: #065f46; border-bottom: 2px solid #065f46; padding-bottom: 4px;">2. Diagnostic Billing Invoices</h3>`;
    html += `<table border="1" cellspacing="0" cellpadding="6">
      <thead style="background-color: #047857; color: white;">
        <tr><th>Invoice No</th><th>Date</th><th>Patient Name</th><th>Phone</th><th>Ref. Doctor</th><th>Total Bill</th><th>Paid</th><th>Due</th></tr>
      </thead><tbody>`;
    bills.forEach((b) => {
      html += `<tr><td>${b.receiptNo}</td><td>${new Date(b.date).toLocaleDateString()}</td><td>${b.patientName} (${b.age})</td><td>${b.phone}</td><td>${b.refDoctorName}</td><td align="right">${b.netTotal} BDT</td><td align="right">${b.paidAmount} BDT</td><td align="right">${b.dueAmount} BDT</td></tr>`;
    });
    html += `</tbody></table><br/><br/>`;

    // 3. Admitted Patients
    html += `<h3 style="color: #065f46; border-bottom: 2px solid #065f46; padding-bottom: 4px;">3. Hospital Admitted Patients</h3>`;
    html += `<table border="1" cellspacing="0" cellpadding="6">
      <thead style="background-color: #047857; color: white;">
        <tr><th>Reg No</th><th>Patient Name</th><th>Guardian & Phone</th><th>Bed/Cabin</th><th>Admission Date</th><th>Status</th><th>Advance Paid</th></tr>
      </thead><tbody>`;
    admissions.forEach((a) => {
      html += `<tr><td>${a.regNo}</td><td>${a.patientName} (${a.age})</td><td>${a.guardianName} | ${a.phone}</td><td>${a.bedName}</td><td>${new Date(a.admissionDate).toLocaleDateString()}</td><td>${a.status}</td><td align="right">${a.advancePaid} BDT</td></tr>`;
    });
    html += `</tbody></table>`;

    exportToExcel(`${hospitalInfo.name.replace(/[^a-zA-Z0-9]/g, '_')}_Master_ERP_Report_${new Date().toISOString().split('T')[0]}`, html);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-900 pb-16">
      {/* Top Navbar Header */}
      <Navbar
        hospitalInfo={hospitalInfo}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          if (tab === 'settings' && !isAdminUnlocked) {
            setShowAdminPinModal(true);
            return;
          }
          setActiveTab(tab);
        }}
        isAdminUnlocked={isAdminUnlocked}
        setIsAdminUnlocked={(val) => {
          if (val) {
            setShowAdminPinModal(true);
          } else {
            setIsAdminUnlocked(false);
          }
        }}
        onExportExcel={handleMasterExcelExport}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'billing' && (
          <DiagnosticBillingView
            tests={tests}
            doctors={doctors}
            bills={bills}
            onAddBill={handleAddBill}
            hospitalInfo={hospitalInfo}
          />
        )}

        {activeTab === 'hospital' && (
          <HospitalManagementView
            beds={beds}
            admissions={admissions}
            doctors={doctors}
            hospitalInfo={hospitalInfo}
            onAdmitPatient={handleAdmitPatient}
            onDischargePatient={handleDischargePatient}
          />
        )}

        {activeTab === 'accounts' && (
          <AccountsDashboardView
            transactions={transactions}
            bills={bills}
            admissions={admissions}
            hospitalInfo={hospitalInfo}
            onAddTransaction={handleAddTransaction}
            isAdminUnlocked={isAdminUnlocked}
            onRequestAdminUnlock={() => setShowAdminPinModal(true)}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsSecurityView
            hospitalInfo={hospitalInfo}
            onUpdateHospitalInfo={setHospitalInfo}
            savedPin={savedPin}
            onUpdatePin={setSavedPin}
            tests={tests}
            onAddTest={(t) => setTests((prev) => [t, ...prev])}
            onDeleteTest={(id) => setTests((prev) => prev.filter((t) => t.id !== id))}
            doctors={doctors}
            onAddDoctor={(d) => setDoctors((prev) => [d, ...prev])}
            onDeleteDoctor={(id) => setDoctors((prev) => prev.filter((d) => d.id !== id))}
            isAdminUnlocked={isAdminUnlocked}
            onRequestAdminUnlock={() => setShowAdminPinModal(true)}
          />
        )}
      </main>

      {/* Admin Verification Modal */}
      {showAdminPinModal && (
        <AdminLockScreen
          savedPin={savedPin}
          onUnlock={() => {
            setIsAdminUnlocked(true);
            setShowAdminPinModal(false);
          }}
          onClose={() => setShowAdminPinModal(false)}
        />
      )}

      {/* Subtle Toast Notifications */}
      <ToastNotification toasts={toasts} onRemove={removeToast} />
    </div>
  );
}
