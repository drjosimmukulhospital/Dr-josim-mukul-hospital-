import React, { useState } from 'react';
import { Lock, ShieldCheck, KeyRound, AlertCircle, X } from 'lucide-react';

interface AdminLockScreenProps {
  onUnlock: () => void;
  onClose?: () => void;
  savedPin: string;
}

export const AdminLockScreen: React.FC<AdminLockScreenProps> = ({ onUnlock, onClose, savedPin }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === savedPin) {
      setError(false);
      onUnlock();
    } else {
      setError(true);
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 p-6 text-white text-center relative">
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-white/70 hover:text-white transition p-1 cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
          )}
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-3 border border-white/20 shadow-inner">
            <Lock className="w-8 h-8 text-amber-300" />
          </div>
          <h2 className="text-xl font-bold font-serif">Admin Security Verification</h2>
          <p className="text-xs text-emerald-100 mt-1">
            Please enter the PIN code to access settings and vital accounting metrics.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="mb-6">
            <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
              <KeyRound className="w-4 h-4 text-emerald-700" />
              <span>Admin PIN Code (PIN)</span>
            </label>
            <input
              type="password"
              value={pin}
              onChange={(e) => {
                setPin(e.target.value);
                if (error) setError(false);
              }}
              placeholder="••••"
              maxLength={6}
              autoFocus
              className="w-full px-4 py-3 bg-slate-50 border-2 border-slate-300 rounded-xl text-center text-2xl font-mono tracking-widest focus:outline-none focus:border-emerald-600 transition"
            />
            {error && (
              <p className="text-red-600 text-xs mt-2 flex items-center gap-1 font-medium animate-bounce">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Incorrect PIN! Please try again (Default: 1234)</span>
              </p>
            )}
            <p className="text-xs text-slate-500 text-center mt-3">
              Default PIN: <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded font-bold text-slate-700">1234</span>
            </p>
          </div>

          <div className="flex gap-3">
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition text-sm cursor-pointer"
              >
                Cancel
              </button>
            )}
            <button
              type="submit"
              className="flex-1 py-3 px-4 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white font-semibold rounded-xl shadow transition text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Unlock</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
