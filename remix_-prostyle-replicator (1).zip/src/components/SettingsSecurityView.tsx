import React, { useState } from 'react';
import { HospitalInfo, DiagnosticTest, Doctor } from '../types';
import { Settings, ShieldCheck, KeyRound, Building2, Stethoscope, Users, Save, Lock, Unlock, AlertCircle, Plus, Trash2, Edit2, Check } from 'lucide-react';

interface SettingsSecurityProps {
  hospitalInfo: HospitalInfo;
  onUpdateHospitalInfo: (info: HospitalInfo) => void;
  savedPin: string;
  onUpdatePin: (newPin: string) => void;
  tests: DiagnosticTest[];
  onAddTest: (test: DiagnosticTest) => void;
  onDeleteTest: (id: string) => void;
  doctors: Doctor[];
  onAddDoctor: (doc: Doctor) => void;
  onDeleteDoctor: (id: string) => void;
  isAdminUnlocked: boolean;
  onRequestAdminUnlock: () => void;
}

export const SettingsSecurityView: React.FC<SettingsSecurityProps> = ({
  hospitalInfo,
  onUpdateHospitalInfo,
  savedPin,
  onUpdatePin,
  tests,
  onAddTest,
  onDeleteTest,
  doctors,
  onAddDoctor,
  onDeleteDoctor,
  isAdminUnlocked,
  onRequestAdminUnlock,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'general' | 'security' | 'tests_catalog' | 'doctors_catalog'>('general');

  // General Hospital Info Form
  const [hName, setHName] = useState(hospitalInfo.name);
  const [hAddress, setHAddress] = useState(hospitalInfo.address);
  const [hPhone, setHPhone] = useState(hospitalInfo.phone);
  const [hEmail, setHEmail] = useState(hospitalInfo.email);
  const [hSlogan, setHSlogan] = useState(hospitalInfo.slogan || '');

  // Pin Change State
  const [currentPinInput, setCurrentPinInput] = useState('');
  const [newPinInput, setNewPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [pinMessage, setPinMessage] = useState<{ text: string; error: boolean } | null>(null);

  // New Test State
  const [newTestName, setNewTestName] = useState('');
  const [newTestCode, setNewTestCode] = useState('');
  const [newTestCat, setNewTestCat] = useState<'Pathology' | 'Radiology' | 'Cardiology' | 'Ultrasound' | 'Biochemistry'>('Pathology');
  const [newTestPrice, setNewTestPrice] = useState('');
  const [newTestRoom, setNewTestRoom] = useState('');

  // New Doctor State
  const [newDocName, setNewDocName] = useState('');
  const [newDocDegree, setNewDocDegree] = useState('');
  const [newDocSpec, setNewDocSpec] = useState('');
  const [newDocPhone, setNewDocPhone] = useState('');
  const [newDocComm, setNewDocComm] = useState('30');

  // Save Hospital Metadata
  const handleSaveHospitalInfo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdminUnlocked) {
      onRequestAdminUnlock();
      return;
    }
    onUpdateHospitalInfo({
      name: hName,
      address: hAddress,
      phone: hPhone,
      email: hEmail,
      slogan: hSlogan,
    });
    alert('Hospital information updated successfully!');
  };

  // Handle Pin Change
  const handlePinChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentPinInput !== savedPin) {
      setPinMessage({ text: 'The current PIN is incorrect!', error: true });
      return;
    }
    if (!newPinInput || newPinInput.length < 4) {
      setPinMessage({ text: 'New PIN must be at least 4 digits long.', error: true });
      return;
    }
    if (newPinInput !== confirmPinInput) {
      setPinMessage({ text: 'New PIN and confirm PIN do not match!', error: true });
      return;
    }

    onUpdatePin(newPinInput);
    setPinMessage({ text: 'Admin security PIN updated successfully!', error: false });
    setCurrentPinInput('');
    setNewPinInput('');
    setConfirmPinInput('');
  };

  // Add Test Catalog Item
  const handleAddNewTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdminUnlocked) {
      onRequestAdminUnlock();
      return;
    }
    if (!newTestName || !newTestPrice) {
      alert('Please enter investigation name and price');
      return;
    }

    const nextId = `t-${Date.now()}`;
    onAddTest({
      id: nextId,
      code: newTestCode || `TST-${Date.now().toString().slice(-4)}`,
      name: newTestName,
      category: newTestCat,
      price: Number(newTestPrice),
      roomNo: newTestRoom || '101',
    });

    setNewTestName('');
    setNewTestCode('');
    setNewTestPrice('');
    setNewTestRoom('');
    alert('New diagnostic test added to catalog!');
  };

  // Add Doctor
  const handleAddNewDoctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdminUnlocked) {
      onRequestAdminUnlock();
      return;
    }
    if (!newDocName) {
      alert("Please enter doctor's name");
      return;
    }

    onAddDoctor({
      id: `d-${Date.now()}`,
      name: newDocName,
      degree: newDocDegree || 'MBBS',
      specialty: newDocSpec || 'General Physician',
      phone: newDocPhone || 'N/A',
      commissionRate: Number(newDocComm) || 0,
    });

    setNewDocName('');
    setNewDocDegree('');
    setNewDocSpec('');
    setNewDocPhone('');
    alert('New doctor added to catalog!');
  };

  return (
    <div className="space-y-6">
      {/* Admin Lock Warning Banner */}
      {!isAdminUnlocked ? (
        <div className="bg-gradient-to-r from-red-800 to-rose-900 text-white p-5 rounded-2xl shadow-lg flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-xl"><Lock className="w-8 h-8 text-amber-300 animate-pulse" /></div>
            <div>
              <h3 className="text-lg font-bold font-serif">Admin Controls Currently Locked</h3>
              <p className="text-xs text-red-100 font-sans">
                Please unlock with your PIN to configure investigations, commission rates, or hospital metadata
              </p>
            </div>
          </div>
          <button
            onClick={onRequestAdminUnlock}
            className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl shadow transition text-sm cursor-pointer whitespace-nowrap"
          >
            Unlock with PIN
          </button>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 text-white p-4 rounded-2xl shadow flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Unlock className="w-5 h-5 text-amber-300" />
            <span className="text-sm font-semibold font-sans">Admin Mode Active (All configurations are editable)</span>
          </div>
        </div>
      )}

      {/* Sub Navbar */}
      <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-200 flex flex-wrap gap-2">
        <button
          onClick={() => setActiveSubTab('general')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            activeSubTab === 'general' ? 'bg-emerald-700 text-white shadow' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Hospital Info & Header</span>
        </button>

        <button
          onClick={() => setActiveSubTab('security')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            activeSubTab === 'security' ? 'bg-emerald-700 text-white shadow' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          <span>Admin Security PIN</span>
        </button>

        <button
          onClick={() => setActiveSubTab('tests_catalog')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            activeSubTab === 'tests_catalog' ? 'bg-emerald-700 text-white shadow' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Diagnostic Test Directory ({tests.length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('doctors_catalog')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            activeSubTab === 'doctors_catalog' ? 'bg-emerald-700 text-white shadow' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Referral Partners & Commissions ({doctors.length})</span>
        </button>
      </div>

      {/* NODE 1: GENERAL HOSPITAL INFO */}
      {activeSubTab === 'general' && (
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 max-w-2xl mx-auto space-y-6">
          <div className="border-b pb-4">
            <h2 className="text-lg font-bold text-slate-800 font-serif">Hospital & Diagnostic Info</h2>
            <p className="text-xs text-slate-500">Configure the metadata printed on invoice receipts & report headers</p>
          </div>

          <form onSubmit={handleSaveHospitalInfo} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Hospital Name</label>
              <input
                type="text"
                required
                value={hName}
                onChange={(e) => setHName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm font-serif font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Address</label>
              <input
                type="text"
                required
                value={hAddress}
                onChange={(e) => setHAddress(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Phone / Mobile</label>
                <input
                  type="text"
                  required
                  value={hPhone}
                  onChange={(e) => setHPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  value={hEmail}
                  onChange={(e) => setHEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Slogan</label>
              <input
                type="text"
                value={hSlogan}
                onChange={(e) => setHSlogan(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={!isAdminUnlocked}
              className={`w-full py-3.5 font-bold rounded-xl shadow transition text-sm flex items-center justify-center gap-2 cursor-pointer ${
                isAdminUnlocked ? 'bg-emerald-700 hover:bg-emerald-600 text-white' : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>Save Information</span>
            </button>
          </form>
        </div>
      )}

      {/* NODE 2: ADMIN SECURITY PIN CHANGE */}
      {activeSubTab === 'security' && (
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 max-w-md mx-auto space-y-6 font-sans">
          <div className="border-b pb-4 text-center">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto mb-2">
              <KeyRound className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-bold text-slate-800 font-serif">Change Admin Security PIN</h2>
            <p className="text-xs text-slate-500">Passcode required to configure rates, pay commissions, or add catalog items</p>
          </div>

          <form onSubmit={handlePinChangeSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Current PIN Code</label>
              <input
                type="password"
                required
                value={currentPinInput}
                onChange={(e) => setCurrentPinInput(e.target.value)}
                placeholder="••••"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-center text-xl tracking-widest"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">New PIN Code</label>
              <input
                type="password"
                required
                value={newPinInput}
                onChange={(e) => setNewPinInput(e.target.value)}
                placeholder="••••"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-center text-xl tracking-widest"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Confirm New PIN Code</label>
              <input
                type="password"
                required
                value={confirmPinInput}
                onChange={(e) => setConfirmPinInput(e.target.value)}
                placeholder="••••"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono text-center text-xl tracking-widest"
              />
            </div>

            {pinMessage && (
              <div className={`p-3 rounded-xl text-xs font-bold text-center ${pinMessage.error ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}`}>
                {pinMessage.text}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white font-bold rounded-xl shadow transition text-sm cursor-pointer"
            >
              Update Security PIN
            </button>
          </form>
        </div>
      )}

      {/* NODE 3: TEST CATALOG CONTROL */}
      {activeSubTab === 'tests_catalog' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4 font-sans">
            <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex items-center gap-2">
              <Plus className="w-4 h-4 text-emerald-600" />
              <span>Add New Investigation / Test</span>
            </h3>

            <form onSubmit={handleAddNewTest} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Test Name *</label>
                <input
                  type="text"
                  required
                  value={newTestName}
                  onChange={(e) => setNewTestName(e.target.value)}
                  placeholder="e.g. Troponin-T"
                  className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Test Code</label>
                  <input
                    type="text"
                    value={newTestCode}
                    onChange={(e) => setNewTestCode(e.target.value)}
                    placeholder="PATH-99"
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Price (BDT) *</label>
                  <input
                    type="number"
                    required
                    value={newTestPrice}
                    onChange={(e) => setNewTestPrice(e.target.value)}
                    placeholder="1200"
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Investigation Dept</label>
                  <select
                    value={newTestCat}
                    onChange={(e: any) => setNewTestCat(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs"
                  >
                    <option value="Pathology">Pathology</option>
                    <option value="Radiology">Radiology</option>
                    <option value="Ultrasound">Ultrasound</option>
                    <option value="Biochemistry">Biochemistry</option>
                    <option value="Cardiology">Cardiology</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Room No</label>
                  <input
                    type="text"
                    value={newTestRoom}
                    onChange={(e) => setNewTestRoom(e.target.value)}
                    placeholder="102"
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={!isAdminUnlocked}
                className={`w-full py-2.5 font-bold rounded-xl shadow transition mt-2 cursor-pointer ${
                  isAdminUnlocked ? 'bg-emerald-700 text-white hover:bg-emerald-600' : 'bg-slate-300 text-slate-500 cursor-not-allowed'
                }`}
              >
                Add to Directory
              </button>
            </form>
          </div>

          <div className="lg:col-span-8 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-3 max-h-[650px] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex justify-between">
              <span>Active Investigations Directory</span>
              <span className="text-xs bg-slate-100 px-2 py-0.5 rounded">{tests.length} tests</span>
            </h3>

            <div className="divide-y divide-slate-100 text-xs">
              {tests.map((t) => (
                <div key={t.id} className="py-2.5 flex justify-between items-center hover:bg-slate-50 px-2 rounded transition">
                  <div className="font-sans">
                    <span className="font-bold text-slate-800">{t.name}</span>
                    <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded ml-2">{t.code}</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">Dept: {t.category} | Room: {t.roomNo}</p>
                  </div>

                  <div className="flex items-center gap-4">
                    <span className="font-mono font-bold text-emerald-700 text-sm">{t.price} BDT</span>
                    {isAdminUnlocked && (
                      <button
                        onClick={() => onDeleteTest(t.id)}
                        className="text-red-500 hover:text-red-700 p-1 cursor-pointer transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* NODE 4: DOCTOR CATALOG & COMMISSION RATES */}
      {activeSubTab === 'doctors_catalog' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4 font-sans">
            <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-600" />
              <span>Add New Referral Partner</span>
            </h3>

            <form onSubmit={handleAddNewDoctor} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Doctor's Name *</label>
                <input
                  type="text"
                  required
                  value={newDocName}
                  onChange={(e) => setNewDocName(e.target.value)}
                  placeholder="e.g. Dr. Harun Or Rashid"
                  className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Degree(s)</label>
                  <input
                    type="text"
                    value={newDocDegree}
                    onChange={(e) => setNewDocDegree(e.target.value)}
                    placeholder="e.g. MBBS, FCPS"
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Commission Rate (%) *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    max={100}
                    value={newDocComm}
                    onChange={(e) => setNewDocComm(e.target.value)}
                    className="w-full px-3 py-2 bg-emerald-50 border border-emerald-400 rounded-lg text-xs font-mono font-bold text-emerald-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Specialty / Dept</label>
                  <input
                    type="text"
                    value={newDocSpec}
                    onChange={(e) => setNewDocSpec(e.target.value)}
                    placeholder="e.g. Medicine Consultant"
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mobile / Hotline</label>
                  <input
                    type="text"
                    value={newDocPhone}
                    onChange={(e) => setNewDocPhone(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full px-3 py-2 bg-slate-50 border rounded-lg text-xs font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={!isAdminUnlocked}
                className={`w-full py-2.5 font-bold rounded-xl shadow transition mt-2 cursor-pointer ${
                  isAdminUnlocked ? 'bg-emerald-700 text-white hover:bg-emerald-600' : 'bg-slate-300 text-slate-500 cursor-not-allowed'
                }`}
              >
                Add Partner
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-3 max-h-[650px] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex justify-between">
              <span>Referral Doctors & Commissions Ledger</span>
              <span className="text-xs bg-slate-100 px-2 py-0.5 rounded">{doctors.length} partners</span>
            </h3>

            <div className="divide-y divide-slate-100 text-xs">
              {doctors.map((d) => (
                <div key={d.id} className="py-3 flex justify-between items-center hover:bg-slate-50 px-2 rounded transition">
                  <div className="font-sans">
                    <span className="font-bold text-slate-900 text-sm block">{d.name}</span>
                    <span className="text-[11px] text-slate-500">{d.degree} ({d.specialty})</span>
                    <p className="text-[11px] font-mono text-slate-400 mt-0.5">{d.phone}</p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right font-sans">
                      <span className="text-[10px] text-slate-400 block">Commission:</span>
                      <span className="font-mono font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded text-xs">
                        {d.commissionRate}%
                      </span>
                    </div>

                    {isAdminUnlocked && d.commissionRate > 0 && (
                      <button
                        onClick={() => onDeleteDoctor(d.id)}
                        className="text-red-500 hover:text-red-700 p-1 cursor-pointer transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
