import React, { useState, useMemo } from 'react';
import { DiagnosticTest, Doctor, PatientBill, BillTestItem, HospitalInfo } from '../types';
import { Plus, Trash2, Printer, Search, Stethoscope, User, Receipt, Award, CheckCircle2 } from 'lucide-react';
import { exportToExcel } from '../utils/excelExport';

interface DiagnosticBillingProps {
  tests: DiagnosticTest[];
  doctors: Doctor[];
  bills: PatientBill[];
  onAddBill: (bill: PatientBill) => void;
  hospitalInfo: HospitalInfo;
}

export const DiagnosticBillingView: React.FC<DiagnosticBillingProps> = ({
  tests,
  doctors,
  bills,
  onAddBill,
  hospitalInfo,
}) => {
  const [subTab, setSubTab] = useState<'entry' | 'history' | 'tests' | 'commissions'>('entry');

  // New Patient Bill Form State
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Child' | 'Others'>('Male');
  const [phone, setPhone] = useState('');
  const [refDoctorId, setRefDoctorId] = useState(doctors[0]?.id || '');
  const [selectedTests, setSelectedTests] = useState<BillTestItem[]>([]);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Card' | 'Mobile Banking'>('Cash');
  const [searchTestQuery, setSearchTestQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  // Printable Modal State
  const [printingBill, setPrintingBill] = useState<PatientBill | null>(null);

  // Commission Filter State
  const [commDoctorId, setCommDoctorId] = useState<string>('all');
  const [commStartDate, setCommStartDate] = useState<string>('');
  const [commEndDate, setCommEndDate] = useState<string>('');

  // Bill Search Query
  const [historyQuery, setHistoryQuery] = useState('');

  // Auto Calculations
  const subTotal = useMemo(() => {
    return selectedTests.reduce((sum, item) => sum + item.price, 0);
  }, [selectedTests]);

  const netTotal = useMemo(() => {
    return Math.max(0, subTotal - (discountAmount || 0));
  }, [subTotal, discountAmount]);

  const dueAmount = useMemo(() => {
    return Math.max(0, netTotal - (paidAmount || 0));
  }, [netTotal, paidAmount]);

  // Handle Add Test to Cart
  const handleAddTest = (test: DiagnosticTest) => {
    if (selectedTests.some((t) => t.testId === test.id)) return;
    setSelectedTests([...selectedTests, { testId: test.id, code: test.code, name: test.name, price: test.price, discount: 0 }]);
    // Auto set paid amount to net total initially for fast checkout
    const newSub = subTotal + test.price;
    const newNet = Math.max(0, newSub - (discountAmount || 0));
    setPaidAmount(newNet);
  };

  const handleRemoveTest = (testId: string) => {
    const next = selectedTests.filter((t) => t.testId !== testId);
    setSelectedTests(next);
    const newSub = next.reduce((s, i) => s + i.price, 0);
    const newNet = Math.max(0, newSub - (discountAmount || 0));
    setPaidAmount(newNet);
  };

  // Submit New Bill
  const handleCreateBill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) {
      alert('Please enter patient name');
      return;
    }
    if (selectedTests.length === 0) {
      alert('Please select at least one diagnostic test');
      return;
    }

    const doctor = doctors.find((d) => d.id === refDoctorId) || doctors[0];
    const newBillId = `INV-${Date.now().toString().slice(-6)}`;
    const nowISO = new Date().toISOString();

    const newBill: PatientBill = {
      id: `b-${Date.now()}`,
      receiptNo: newBillId,
      patientName,
      age: age ? `${age} Years` : 'N/A',
      gender,
      phone: phone || 'N/A',
      refDoctorId: doctor ? doctor.id : 'N/A',
      refDoctorName: doctor ? doctor.name : 'Self',
      tests: selectedTests,
      subTotal,
      discountAmount: Number(discountAmount) || 0,
      netTotal,
      paidAmount: Number(paidAmount) || 0,
      dueAmount,
      paymentMethod,
      date: nowISO,
      deliveryDate: new Date(Date.now() + 6 * 3600 * 1000).toISOString(), // +6 hours
      status: dueAmount === 0 ? 'Paid' : 'Due',
    };

    onAddBill(newBill);
    setPrintingBill(newBill);

    // Reset Form
    setPatientName('');
    setAge('');
    setPhone('');
    setSelectedTests([]);
    setDiscountAmount(0);
    setPaidAmount(0);
  };

  // Filtered Test Catalog
  const filteredCatalog = useMemo(() => {
    return tests.filter((t) => {
      const matchCat = selectedCategory === 'All' || t.category === selectedCategory;
      const matchQuery = t.name.toLowerCase().includes(searchTestQuery.toLowerCase()) || t.code.toLowerCase().includes(searchTestQuery.toLowerCase());
      return matchCat && matchQuery;
    });
  }, [tests, selectedCategory, searchTestQuery]);

  // Filtered Bills History
  const filteredBills = useMemo(() => {
    return bills.filter((b) => {
      return b.patientName.toLowerCase().includes(historyQuery.toLowerCase()) || b.receiptNo.toLowerCase().includes(historyQuery.toLowerCase()) || b.phone.includes(historyQuery);
    });
  }, [bills, historyQuery]);

  // Doctor Commission Calculations
  const commissionReport = useMemo(() => {
    let list = bills;
    if (commDoctorId !== 'all') {
      list = list.filter((b) => b.refDoctorId === commDoctorId);
    }
    if (commStartDate) {
      list = list.filter((b) => b.date.split('T')[0] >= commStartDate);
    }
    if (commEndDate) {
      list = list.filter((b) => b.date.split('T')[0] <= commEndDate);
    }

    const reportByDoc: Record<string, { docName: string; totalBilled: number; totalDiscount: number; netCollected: number; commissionAmount: number; rate: number; count: number }> = {};

    list.forEach((b) => {
      const doc = doctors.find((d) => d.id === b.refDoctorId);
      const docId = b.refDoctorId || 'unknown';
      const docName = b.refDoctorName || 'Self';
      const rate = doc ? doc.commissionRate : 0;

      if (!reportByDoc[docId]) {
        reportByDoc[docId] = { docName, totalBilled: 0, totalDiscount: 0, netCollected: 0, commissionAmount: 0, rate, count: 0 };
      }

      reportByDoc[docId].totalBilled += b.subTotal;
      reportByDoc[docId].totalDiscount += b.discountAmount;
      reportByDoc[docId].netCollected += b.netTotal;
      // Commission computed on Net Total
      reportByDoc[docId].commissionAmount += Math.round((b.netTotal * rate) / 100);
      reportByDoc[docId].count += 1;
    });

    return Object.values(reportByDoc);
  }, [bills, commDoctorId, commStartDate, commEndDate, doctors]);

  // Export Commission Report to Excel
  const exportCommissionExcel = () => {
    let rowsHtml = '';
    let totalNet = 0;
    let totalComm = 0;

    commissionReport.forEach((r, idx) => {
      totalNet += r.netCollected;
      totalComm += r.commissionAmount;
      rowsHtml += `
        <tr>
          <td style="text-align: center;">${idx + 1}</td>
          <td>${r.docName}</td>
          <td style="text-align: center;">${r.count} Patients</td>
          <td style="text-align: right;">${r.totalBilled} BDT</td>
          <td style="text-align: right;">${r.netCollected} BDT</td>
          <td style="text-align: center;">${r.rate}%</td>
          <td style="text-align: right; font-weight: bold; color: #059669;">${r.commissionAmount} BDT</td>
        </tr>
      `;
    });

    const html = `
      <div style="text-align: center; margin-bottom: 20px;">
        <h2>${hospitalInfo.name}</h2>
        <p>${hospitalInfo.address}</p>
        <h3>Referral Doctor Commission Report (%)</h3>
        <p>Date Range: ${commStartDate || 'Start'} to ${commEndDate || 'Today'}</p>
      </div>
      <table border="1" cellspacing="0" cellpadding="6">
        <thead>
          <tr style="background-color: #0f766e; color: white;">
            <th>Sl. No</th>
            <th>Doctor Name</th>
            <th>Patient Count</th>
            <th>Total Billed</th>
            <th>Net Billed</th>
            <th>Commission Rate</th>
            <th>Total Commission Due</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
        <tfoot>
          <tr style="background-color: #f3f4f6; font-weight: bold;">
            <td colspan="4" style="text-align: right;">Grand Total:</td>
            <td style="text-align: right;">${totalNet} BDT</td>
            <td></td>
            <td style="text-align: right; color: #059669;">${totalComm} BDT</td>
          </tr>
        </tfoot>
      </table>
    `;

    exportToExcel(`Doctor_Commission_Report_${new Date().toISOString().split('T')[0]}`, html);
  };

  return (
    <div className="space-y-6">
      {/* Sub Navbar for Flowchart Nodes */}
      <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-200 flex flex-wrap gap-2">
        <button
          onClick={() => setSubTab('entry')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'entry'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>Patient Entry & Billing</span>
        </button>

        <button
          onClick={() => setSubTab('history')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'history'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Receipt Print & Invoices ({bills.length})</span>
        </button>

        <button
          onClick={() => setSubTab('tests')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'tests'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Stethoscope className="w-4 h-4" />
          <span>Diagnostic Test Rate Card ({tests.length})</span>
        </button>

        <button
          onClick={() => setSubTab('commissions')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'commissions'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Doctor Commission Accounts %</span>
        </button>
      </div>

      {/* NODE 1 & 2: PATIENT ENTRY & BILL AUTO CALCULATION */}
      {subTab === 'entry' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Form & Cart */}
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
            <div className="border-b border-slate-200 pb-4">
              <h2 className="text-lg font-bold text-slate-800 font-serif flex items-center gap-2">
                <User className="w-5 h-5 text-emerald-600" />
                <span>Patient Registration Info</span>
              </h2>
            </div>

            <form onSubmit={handleCreateBill} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Patient Name *</label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="e.g. Md. Josim Uddin"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 focus:bg-white transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Age</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    placeholder="e.g. 35"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 focus:bg-white transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e: any) => setGender(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 transition"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Child">Child</option>
                    <option value="Others">Others</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Mobile Number</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Referral Doctor *</label>
                  <select
                    value={refDoctorId}
                    onChange={(e) => setRefDoctorId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium focus:outline-none focus:border-emerald-600 transition"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.commissionRate}%)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Selected Tests Cart */}
              <div className="pt-4">
                <h3 className="text-sm font-bold text-slate-700 mb-2 flex justify-between items-center">
                  <span>Selected Tests ({selectedTests.length})</span>
                  <span className="text-xs text-emerald-600 font-normal">Click tests from the right catalog to add</span>
                </h3>

                <div className="min-h-40 max-h-60 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50/50 p-2">
                  {selectedTests.length === 0 ? (
                    <div className="h-32 flex flex-col items-center justify-center text-slate-400 text-xs">
                      <Stethoscope className="w-8 h-8 mb-1 opacity-40" />
                      <span>No tests selected</span>
                    </div>
                  ) : (
                    selectedTests.map((item) => (
                      <div key={item.testId} className="py-2 px-3 flex justify-between items-center bg-white my-1 rounded-lg shadow-2xs border border-slate-100">
                        <div>
                          <p className="text-xs font-bold text-slate-800">{item.name}</p>
                          <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">{item.code}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-xs font-bold text-emerald-700">{item.price} BDT</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveTest(item.testId)}
                            className="text-red-500 hover:text-red-700 transition p-1 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* AUTO BILL CALCULATION PANEL */}
              <div className="bg-gradient-to-br from-slate-900 to-emerald-950 text-white p-5 rounded-2xl shadow-md space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">Billing Auto-Calculation</h4>
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-300">Subtotal:</span>
                    <span className="font-mono font-bold">{subTotal} BDT</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-slate-300">Discount Amount:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min={0}
                        max={subTotal}
                        value={discountAmount || ''}
                        onChange={(e) => {
                          const val = Number(e.target.value) || 0;
                          setDiscountAmount(val);
                          setPaidAmount(Math.max(0, subTotal - val));
                        }}
                        className="w-20 px-2 py-1 bg-white/10 border border-white/20 rounded text-right font-mono text-sm focus:outline-none focus:bg-white focus:text-slate-900 transition"
                      />
                      <span>BDT</span>
                    </div>
                  </div>

                  <div className="flex justify-between pt-2 border-t border-white/10 text-base font-bold">
                    <span className="text-emerald-300">Net Total:</span>
                    <span className="font-mono text-emerald-300">{netTotal} BDT</span>
                  </div>

                  <div className="flex justify-between items-center pt-1">
                    <span className="text-slate-300">Paid Amount:</span>
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min={0}
                        max={netTotal}
                        value={paidAmount || ''}
                        onChange={(e) => setPaidAmount(Number(e.target.value) || 0)}
                        className="w-24 px-2 py-1 bg-emerald-500/30 border border-emerald-400 rounded text-right font-mono text-sm font-bold focus:outline-none focus:bg-white focus:text-slate-900 transition"
                      />
                      <span>BDT</span>
                    </div>
                  </div>

                  <div className="flex justify-between text-xs pt-1">
                    <span className="text-slate-400">Payment Method:</span>
                    <select
                      value={paymentMethod}
                      onChange={(e: any) => setPaymentMethod(e.target.value)}
                      className="bg-slate-800 text-white text-xs px-2 py-0.5 rounded border border-slate-700 cursor-pointer"
                    >
                      <option value="Cash">Cash</option>
                      <option value="Card">Card</option>
                      <option value="Mobile Banking">Mobile Banking</option>
                    </select>
                  </div>

                  {dueAmount > 0 ? (
                    <div className="flex justify-between bg-red-500/20 px-3 py-1.5 rounded-lg border border-red-500/40 text-red-300 font-bold text-xs mt-2">
                      <span>Due Amount:</span>
                      <span className="font-mono">{dueAmount} BDT</span>
                    </div>
                  ) : (
                    <div className="flex justify-between bg-emerald-500/20 px-3 py-1.5 rounded-lg border border-emerald-500/40 text-emerald-300 font-bold text-xs mt-2">
                      <span>Status:</span>
                      <span>Fully Paid ✓</span>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full mt-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Receipt className="w-5 h-5" />
                  <span>Confirm Bill & Print Receipt</span>
                </button>
              </div>
            </form>
          </div>

          {/* Right Column: Searchable Test Catalog */}
          <div className="lg:col-span-5 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col h-[750px]">
            <div className="border-b border-slate-200 pb-4 mb-4">
              <h2 className="text-base font-bold text-slate-800 font-serif flex items-center justify-between">
                <span>Diagnostic Test Catalog</span>
                <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-sans">
                  Rates updated
                </span>
              </h2>

              <div className="mt-3 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={searchTestQuery}
                  onChange={(e) => setSearchTestQuery(e.target.value)}
                  placeholder="Search tests (name or code)..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-xl text-sm focus:outline-none focus:border-emerald-600 transition"
                />
              </div>

              {/* Category Filters */}
              <div className="flex gap-1.5 overflow-x-auto mt-3 pb-1 scrollbar-none">
                {['All', 'Pathology', 'Radiology', 'Ultrasound', 'Biochemistry', 'Cardiology'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition whitespace-nowrap cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-emerald-800 text-white shadow-2xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Test Catalog Items */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredCatalog.map((test) => {
                const isSelected = selectedTests.some((t) => t.testId === test.id);
                return (
                  <div
                    key={test.id}
                    onClick={() => handleAddTest(test)}
                    className={`p-3 rounded-xl border transition cursor-pointer flex justify-between items-center ${
                      isSelected
                        ? 'bg-emerald-50 border-emerald-400 shadow-2xs'
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-800">{test.name}</span>
                        <span className="text-[10px] font-mono bg-slate-100 px-1 rounded text-slate-600">{test.code}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Dept: <span className="font-semibold text-emerald-800">{test.category}</span> {test.roomNo && `| Room: ${test.roomNo}`}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-emerald-700 font-mono">{test.price} BDT</span>
                      <button
                        type="button"
                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition ${
                          isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-emerald-100'
                        }`}
                      >
                        {isSelected ? <CheckCircle2 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* NODE 3: RECEIPT PRINT & BILL HISTORY */}
      {subTab === 'history' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-200 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800 font-serif">Diagnostic Invoice Ledger & History</h2>
              <p className="text-xs text-slate-500">View and print invoices or process pending billing records</p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={historyQuery}
                onChange={(e) => setHistoryQuery(e.target.value)}
                placeholder="Search Invoice No or Patient Name..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <th className="p-3">Invoice No</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Patient Name & Phone</th>
                  <th className="p-3">Referral Doctor</th>
                  <th className="p-3 text-right">Total Bill</th>
                  <th className="p-3 text-right">Paid</th>
                  <th className="p-3 text-right">Due</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredBills.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-mono font-bold text-emerald-800">{b.receiptNo}</td>
                    <td className="p-3">{new Date(b.date).toLocaleDateString()}</td>
                    <td className="p-3">
                      <div className="font-bold text-slate-800">{b.patientName}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{b.phone}</div>
                    </td>
                    <td className="p-3">{b.refDoctorName}</td>
                    <td className="p-3 text-right font-mono font-bold">{b.netTotal} BDT</td>
                    <td className="p-3 text-right font-mono text-emerald-700">{b.paidAmount} BDT</td>
                    <td className="p-3 text-right font-mono text-red-600 font-bold">{b.dueAmount > 0 ? `${b.dueAmount} BDT` : '-'}</td>
                    <td className="p-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          b.status === 'Paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => setPrintingBill(b)}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg flex items-center gap-1 mx-auto text-xs font-semibold transition shadow-2xs cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Receipt</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* NODE 4: DIAGNOSTIC 150-200 TEST CATALOG FULL VIEW */}
      {subTab === 'tests' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-200 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800 font-serif">Diagnostic Tests & Pricing Catalog</h2>
              <p className="text-xs text-slate-500">Official pricing rates for all pathology, cardiology, and radiology investigations</p>
            </div>
            <span className="text-xs bg-emerald-800 text-white px-3 py-1 rounded-lg font-bold">
              Total Investigations: {tests.length}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {tests.map((t) => (
              <div key={t.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl hover:shadow-md transition">
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-mono bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                    {t.code}
                  </span>
                  <span className="text-sm font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {t.price} BDT
                  </span>
                </div>
                <h3 className="text-sm font-bold text-slate-800">{t.name}</h3>
                <p className="text-xs text-slate-500 mt-1">Dept: {t.category} {t.roomNo && `| Room: ${t.roomNo}`}</p>
                {t.normalRange && (
                  <p className="text-[11px] text-teal-800 mt-2 font-mono bg-teal-50 p-1.5 rounded border border-teal-200">
                    Normal Range: {t.normalRange}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* NODE 5: REFER DOCTOR COMMISSION % CALCULATION WITH DATE FILTER */}
      {subTab === 'commissions' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
          <div className="border-b border-slate-200 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h2 className="text-lg font-bold text-slate-800 font-serif flex items-center gap-2">
                <Award className="w-5 h-5 text-emerald-600" />
                <span>Referral Doctor Commissions</span>
              </h2>
              <p className="text-xs text-slate-500">Track and calculate doctor refer commissions based on net collected bills</p>
            </div>

            <button
              onClick={exportCommissionExcel}
              className="px-4 py-2 bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition cursor-pointer flex items-center gap-1.5"
            >
              <span>Export Commission Excel</span>
            </button>
          </div>

          {/* Filters Bar */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Select Doctor</label>
              <select
                value={commDoctorId}
                onChange={(e) => setCommDoctorId(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs cursor-pointer"
              >
                <option value="all">All Doctors Combined</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.commissionRate}%)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Start Date</label>
              <input
                type="date"
                value={commStartDate}
                onChange={(e) => setCommStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">End Date</label>
              <input
                type="date"
                value={commEndDate}
                onChange={(e) => setCommEndDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono"
              />
            </div>

            <div className="flex items-end">
              <button
                type="button"
                onClick={() => {
                  setCommDoctorId('all');
                  setCommStartDate('');
                  setCommEndDate('');
                }}
                className="w-full py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-semibold transition cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          </div>

          {/* Commission Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-200">
              <span className="text-xs text-emerald-800 font-bold">Total Investigations Revenue</span>
              <p className="text-2xl font-mono font-bold text-emerald-950 mt-1">
                {commissionReport.reduce((s, r) => s + r.netCollected, 0).toLocaleString()} BDT
              </p>
            </div>

            <div className="bg-amber-50 p-4 rounded-xl border border-amber-200">
              <span className="text-xs text-amber-800 font-bold">Total Referred Patients</span>
              <p className="text-2xl font-mono font-bold text-amber-950 mt-1">
                {commissionReport.reduce((s, r) => s + r.count, 0)} Patients
              </p>
            </div>

            <div className="bg-teal-900 text-white p-4 rounded-xl shadow">
              <span className="text-xs text-teal-300 font-bold">Total Commission Payable</span>
              <p className="text-2xl font-mono font-bold text-white mt-1">
                {commissionReport.reduce((s, r) => s + r.commissionAmount, 0).toLocaleString()} BDT
              </p>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <th className="p-3">Doctor Name</th>
                  <th className="p-3 text-center">Patients Referred</th>
                  <th className="p-3 text-right">Subtotal</th>
                  <th className="p-3 text-right">Net Revenue</th>
                  <th className="p-3 text-center">Commission Rate (%)</th>
                  <th className="p-3 text-right">Payable Commission</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {commissionReport.map((r, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-bold text-slate-800">{r.docName}</td>
                    <td className="p-3 text-center font-mono">{r.count} Patients</td>
                    <td className="p-3 text-right font-mono">{r.totalBilled} BDT</td>
                    <td className="p-3 text-right font-mono font-semibold">{r.netCollected} BDT</td>
                    <td className="p-3 text-center">
                      <span className="bg-slate-100 font-mono px-2 py-0.5 rounded font-bold text-slate-700">{r.rate}%</span>
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-emerald-700 text-sm">
                      {r.commissionAmount.toLocaleString()} BDT
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* RECEIPT PRINT MODAL */}
      {printingBill && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-300 flex flex-col max-h-[90vh]">
            {/* Printable Receipt Area */}
            <div id="receipt-print-area" className="p-6 overflow-y-auto space-y-4 font-sans text-slate-800 text-xs">
              <div className="text-center border-b border-slate-300 pb-4">
                <h2 className="text-lg font-bold font-serif text-emerald-900">{hospitalInfo.name}</h2>
                <p className="text-[11px] text-slate-600">{hospitalInfo.address}</p>
                <p className="text-[11px] font-mono font-semibold">Hotline: {hospitalInfo.phone}</p>
                <div className="mt-2 inline-block bg-emerald-800 text-white px-3 py-0.5 rounded text-[11px] font-bold tracking-wider uppercase">
                  Diagnostic Cash Receipt
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div><span className="font-semibold">Invoice No:</span> <span className="font-mono">{printingBill.receiptNo}</span></div>
                <div><span className="font-semibold">Date:</span> {new Date(printingBill.date).toLocaleString()}</div>
                <div><span className="font-semibold">Patient Name:</span> {printingBill.patientName}</div>
                <div><span className="font-semibold">Age & Gender:</span> {printingBill.age}, {printingBill.gender}</div>
                <div><span className="font-semibold">Mobile:</span> <span className="font-mono">{printingBill.phone}</span></div>
                <div><span className="font-semibold">Ref. Doctor:</span> {printingBill.refDoctorName}</div>
              </div>

              <table className="w-full border-collapse border border-slate-300 text-[11px]">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="border border-slate-300 p-2 text-left">Sl. No</th>
                    <th className="border border-slate-300 p-2 text-left">Investigation / Test Name</th>
                    <th className="border border-slate-300 p-2 text-right">Price (BDT)</th>
                  </tr>
                </thead>
                <tbody>
                  {printingBill.tests.map((item, idx) => (
                    <tr key={idx}>
                      <td className="border border-slate-300 p-2 text-center">{idx + 1}</td>
                      <td className="border border-slate-300 p-2">{item.name}</td>
                      <td className="border border-slate-300 p-2 text-right font-mono">{item.price}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="space-y-1 text-right text-[12px] pt-2 border-t border-slate-300">
                <p>Subtotal: <span className="font-mono font-bold">{printingBill.subTotal} BDT</span></p>
                <p>Discount: <span className="font-mono text-red-600">-{printingBill.discountAmount} BDT</span></p>
                <p className="text-sm font-bold text-emerald-900 border-t border-slate-200 pt-1">
                  Net Amount: <span className="font-mono">{printingBill.netTotal} BDT</span>
                </p>
                <p className="font-semibold">Paid Amount: <span className="font-mono text-emerald-700">{printingBill.paidAmount} BDT</span></p>
                {printingBill.dueAmount > 0 ? (
                  <p className="text-red-600 font-bold">Due Amount: <span className="font-mono">{printingBill.dueAmount} BDT</span></p>
                ) : (
                  <p className="text-emerald-700 font-bold">Status: Fully Paid ✓</p>
                )}
              </div>

              <div className="pt-8 flex justify-between text-[10px] text-slate-500 text-center">
                <div className="border-t border-slate-400 pt-1 px-4">Patient's Signature</div>
                <div className="border-t border-slate-400 pt-1 px-4">Authorized Signature</div>
              </div>

              <p className="text-[10px] text-center text-slate-400 pt-2">
                Please bring this money receipt when receiving medical test reports. Thank you.
              </p>
            </div>

            {/* Modal Actions */}
            <div className="bg-slate-100 p-4 border-t border-slate-200 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setPrintingBill(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl text-xs transition cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow transition text-xs flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print Invoice</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
