import React, { useState, useMemo } from 'react';
import { AccountTransaction, HospitalInfo, PatientBill, AdmittedPatient } from '../types';
import { Wallet, TrendingUp, TrendingDown, DollarSign, PlusCircle, ArrowDownRight, ArrowUpRight, FileSpreadsheet, Calendar, PieChart, BarChart3, Filter, ShieldAlert } from 'lucide-react';
import { exportTransactionsToExcel } from '../utils/excelExport';

interface AccountsDashboardProps {
  transactions: AccountTransaction[];
  bills: PatientBill[];
  admissions: AdmittedPatient[];
  hospitalInfo: HospitalInfo;
  onAddTransaction: (tx: AccountTransaction) => void;
  isAdminUnlocked: boolean;
  onRequestAdminUnlock: () => void;
}

export const AccountsDashboardView: React.FC<AccountsDashboardProps> = ({
  transactions,
  bills,
  admissions,
  hospitalInfo,
  onAddTransaction,
  isAdminUnlocked,
  onRequestAdminUnlock,
}) => {
  const [subTab, setSubTab] = useState<'dashboard' | 'ledger' | 'add_expense'>('dashboard');

  // New Transaction Form State
  const [txType, setTxType] = useState<'Income' | 'Expense'>('Expense');
  const [txCategory, setTxCategory] = useState<any>('Pharmacy');
  const [txAmount, setTxAmount] = useState('');
  const [txDesc, setTxDesc] = useState('');
  const [filterType, setFilterType] = useState<'All' | 'Income' | 'Expense'>('All');

  // Totals Calculation
  const { totalIncome, totalExpense, netBalance } = useMemo(() => {
    let inc = 0;
    let exp = 0;
    transactions.forEach((t) => {
      if (t.type === 'Income') inc += t.amount;
      else exp += t.amount;
    });
    return { totalIncome: inc, totalExpense: exp, netBalance: inc - exp };
  }, [transactions]);

  // Handle Add Transaction
  const handleAddTxSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdminUnlocked) {
      onRequestAdminUnlock();
      return;
    }
    if (!txAmount || Number(txAmount) <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    const newTx: AccountTransaction = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString(),
      type: txType,
      category: txCategory,
      description: txDesc || `${txCategory} - ${txType}`,
      amount: Number(txAmount),
    };

    onAddTransaction(newTx);
    setTxAmount('');
    setTxDesc('');
    alert('Transaction logged successfully!');
  };

  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => filterType === 'All' || t.type === filterType);
  }, [transactions, filterType]);

  return (
    <div className="space-y-6">
      {/* Sub Navbar */}
      <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-200 flex flex-wrap justify-between items-center gap-2">
        <div className="flex gap-2">
          <button
            onClick={() => setSubTab('dashboard')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
              subTab === 'dashboard'
                ? 'bg-emerald-700 text-white shadow'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <PieChart className="w-4 h-4" />
            <span>Hospital Dashboard</span>
          </button>

          <button
            onClick={() => setSubTab('ledger')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
              subTab === 'ledger'
                ? 'bg-emerald-700 text-white shadow'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Hospital Account Ledger ({transactions.length})</span>
          </button>

          <button
            onClick={() => setSubTab('add_expense')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
              subTab === 'add_expense'
                ? 'bg-emerald-700 text-white shadow'
                : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
            }`}
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Transaction</span>
          </button>
        </div>

        <button
          onClick={() => exportTransactionsToExcel(hospitalInfo.name, hospitalInfo.address, hospitalInfo.phone, transactions)}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-bold rounded-lg shadow cursor-pointer transition"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
          <span>Export Ledger to Excel (.xls)</span>
        </button>
      </div>

      {/* NODE 1: HOSPITAL DASHBOARD SUMMARY */}
      {subTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Top KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="bg-gradient-to-br from-emerald-800 to-teal-900 text-white p-6 rounded-2xl shadow-md border border-emerald-700 relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-xs text-emerald-300 uppercase font-bold tracking-wider">Total Hospital Revenue</span>
                  <h3 className="text-3xl font-mono font-bold mt-2">{totalIncome.toLocaleString()} BDT</h3>
                </div>
                <div className="p-3 bg-white/10 rounded-xl"><ArrowUpRight className="w-6 h-6 text-emerald-300" /></div>
              </div>
              <p className="text-xs text-emerald-200 mt-4 flex items-center gap-1">
                <span>Received from diagnostic investigations & hospital in-patient bills</span>
              </p>
            </div>

            <div className="bg-gradient-to-br from-red-800 to-rose-900 text-white p-6 rounded-2xl shadow-md border border-red-700 relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-xs text-red-300 uppercase font-bold tracking-wider">Total Expenditures</span>
                  <h3 className="text-3xl font-mono font-bold mt-2">{totalExpense.toLocaleString()} BDT</h3>
                </div>
                <div className="p-3 bg-white/10 rounded-xl"><ArrowDownRight className="w-6 h-6 text-red-300" /></div>
              </div>
              <p className="text-xs text-red-200 mt-4 flex items-center gap-1">
                <span>Spent on pharmacy, employee salaries, utility bills & doctor commissions</span>
              </p>
            </div>

            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-6 rounded-2xl shadow-md border border-slate-700 relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-xs text-slate-300 uppercase font-bold tracking-wider">Net Account Balance</span>
                  <h3 className={`text-3xl font-mono font-bold mt-2 ${netBalance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {netBalance.toLocaleString()} BDT
                  </h3>
                </div>
                <div className="p-3 bg-white/10 rounded-xl"><Wallet className="w-6 h-6 text-amber-300" /></div>
              </div>
              <p className="text-xs text-slate-400 mt-4">
                {netBalance >= 0 ? 'Hospital account is in surplus ✓' : 'Hospital account is in deficit!'}
              </p>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
              <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-emerald-600" />
                <span>Primary Revenue Streams</span>
              </h3>

              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-xl border border-emerald-100">
                  <span className="text-xs font-bold text-emerald-900 font-sans">Diagnostic Investigations ({bills.length} Invoices)</span>
                  <span className="font-mono font-bold text-emerald-800">
                    {bills.reduce((s, b) => s + b.paidAmount, 0).toLocaleString()} BDT
                  </span>
                </div>

                <div className="flex justify-between items-center p-3 bg-teal-50 rounded-xl border border-teal-100">
                  <span className="text-xs font-bold text-teal-900 font-sans">In-Patient Admissions & Advances ({admissions.length} Admitted)</span>
                  <span className="font-mono font-bold text-teal-800">
                    {admissions.reduce((s, a) => s + a.advancePaid, 0).toLocaleString()} BDT
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
              <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex items-center gap-2">
                <PieChart className="w-5 h-5 text-red-600" />
                <span>Primary Expense Streams</span>
              </h3>

              <div className="space-y-3">
                {[
                  { key: 'Pharmacy', label: 'Pharmacy & Surgical restock' },
                  { key: 'Salary & Allowance', label: 'Doctor & Staff Salaries' },
                  { key: 'Utility Bill', label: 'Electricity & Utilities' },
                  { key: 'Doctor Commission', label: 'Doctor Referral Commissions' },
                  { key: 'Other Expenses', label: 'Miscellaneous Expenses' },
                ].map((item) => {
                  const amt = transactions.filter((t) => t.type === 'Expense' && t.category === item.key).reduce((s, t) => s + t.amount, 0);
                  if (amt === 0) return null;
                  return (
                    <div key={item.key} className="flex justify-between items-center p-3 bg-red-50/60 rounded-xl border border-red-100 text-xs">
                      <span className="font-bold text-red-900 font-sans">{item.label}</span>
                      <span className="font-mono font-bold text-red-700">{amt.toLocaleString()} BDT</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* NODE 2: FULL LEDGER LIST */}
      {subTab === 'ledger' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800 font-serif">Hospital Account Ledger</h2>
              <p className="text-xs text-slate-500">Full ledger logging of daily hospital revenues and expenditures</p>
            </div>

            <div className="flex gap-2 font-sans">
              <button
                onClick={() => setFilterType('All')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${filterType === 'All' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600'}`}
              >
                All Transactions
              </button>
              <button
                onClick={() => setFilterType('Income')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${filterType === 'Income' ? 'bg-emerald-700 text-white' : 'bg-emerald-50 text-emerald-800'}`}
              >
                Income (+)
              </button>
              <button
                onClick={() => setFilterType('Expense')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition ${filterType === 'Expense' ? 'bg-red-700 text-white' : 'bg-red-50 text-red-800'}`}
              >
                Expenses (-)
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b">
                  <th className="p-3 text-center">Sl.</th>
                  <th className="p-3">Date & Time</th>
                  <th className="p-3">Type</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Description</th>
                  <th className="p-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.map((t, idx) => (
                  <tr key={t.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 text-center font-mono">{idx + 1}</td>
                    <td className="p-3 font-mono">{new Date(t.date).toLocaleString()}</td>
                    <td className="p-3 font-sans">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${t.type === 'Income' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                        {t.type}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-slate-800">{t.category}</td>
                    <td className="p-3 text-slate-600 font-sans">{t.description}</td>
                    <td className={`p-3 text-right font-mono font-bold text-sm ${t.type === 'Income' ? 'text-emerald-700' : 'text-red-600'}`}>
                      {t.type === 'Income' ? '+' : '-'}{t.amount.toLocaleString()} BDT
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* NODE 3: ADD EXPENSE / INCOME FORM */}
      {subTab === 'add_expense' && (
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-slate-200 space-y-6">
          <div className="border-b pb-4">
            <h2 className="text-lg font-bold text-slate-800 font-serif flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-emerald-600" />
              <span>Add New Hospital Transaction</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">Log pharmacy stock entries, staffing overheads, utilities, or grants</p>
          </div>

          {!isAdminUnlocked && (
            <div className="p-4 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-center justify-between font-sans">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-600 animate-pulse" />
                <span>Admin PIN authentication is required to submit manual transactions.</span>
              </div>
              <button
                type="button"
                onClick={onRequestAdminUnlock}
                className="px-3 py-1 bg-amber-600 text-white rounded-lg font-bold cursor-pointer"
              >
                Unlock with PIN
              </button>
            </div>
          )}

          <form onSubmit={handleAddTxSubmit} className="space-y-4 font-sans">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Transaction Type *</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTxType('Expense');
                      setTxCategory('Pharmacy');
                    }}
                    className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer ${txType === 'Expense' ? 'bg-red-600 text-white shadow' : 'bg-slate-100 text-slate-700'}`}
                  >
                    Expense (-)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTxType('Income');
                      setTxCategory('Other Expenses'); // Will map to list
                    }}
                    className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer ${txType === 'Income' ? 'bg-emerald-600 text-white shadow' : 'bg-slate-100 text-slate-700'}`}
                  >
                    Other Income (+)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Category *</label>
                <select
                  value={txCategory}
                  onChange={(e) => setTxCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold"
                >
                  {txType === 'Expense' ? (
                    <>
                      <option value="Pharmacy">Pharmacy & Surgical Purchases</option>
                      <option value="Salary & Allowance">Staff Salaries & Allowances</option>
                      <option value="Utility Bill">Electricity / Generator / Utilities</option>
                      <option value="Doctor Commission">Doctor Referral Commissions</option>
                      <option value="Other Expenses">Miscellaneous Expenses</option>
                    </>
                  ) : (
                    <>
                      <option value="Other Expenses">Miscellaneous Income / Grants</option>
                      <option value="Pharmacy">Pharmacy Sales Receipt</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Amount *</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  required
                  min={1}
                  value={txAmount}
                  onChange={(e) => setTxAmount(e.target.value)}
                  placeholder="e.g. 4500"
                  className="w-full px-4 py-3 bg-slate-50 border-2 border-slate-300 rounded-xl font-mono text-lg font-bold focus:outline-none focus:border-emerald-600 transition"
                />
                <span className="text-xl font-bold text-slate-700">BDT</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Description / Note (Optional)</label>
              <textarea
                rows={3}
                value={txDesc}
                onChange={(e) => setTxDesc(e.target.value)}
                placeholder="Enter transaction details..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 transition"
              />
            </div>

            <button
              type="submit"
              disabled={!isAdminUnlocked}
              className={`w-full py-3.5 font-bold rounded-xl shadow-lg transition text-sm flex items-center justify-center gap-2 cursor-pointer ${
                isAdminUnlocked
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white'
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
            >
              <PlusCircle className="w-5 h-5" />
              <span>Submit Transaction</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
