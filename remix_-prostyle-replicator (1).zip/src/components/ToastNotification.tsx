import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, Database, X } from 'lucide-react';

export interface ToastItem {
  id: string;
  message: string;
  type?: 'success' | 'info' | 'warning';
}

interface ToastNotificationProps {
  toasts: ToastItem[];
  onRemove: (id: string) => void;
}

export const ToastNotification: React.FC<ToastNotificationProps> = ({ toasts, onRemove }) => {
  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-xs sm:max-w-sm w-full pointer-events-none px-4 sm:px-0">
      <AnimatePresence>
        {toasts.map((toast) => (
          <ToastItemComponent key={toast.id} toast={toast} onRemove={onRemove} />
        ))}
      </AnimatePresence>
    </div>
  );
};

const ToastItemComponent: React.FC<{ toast: ToastItem; onRemove: (id: string) => void }> = ({ toast, onRemove }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onRemove(toast.id);
    }, 4000);
    return () => clearTimeout(timer);
  }, [toast.id, onRemove]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
      className="pointer-events-auto bg-slate-900 text-white rounded-xl shadow-xl border border-slate-800 p-4 flex items-start gap-3 relative overflow-hidden"
    >
      {/* Decorative progress bar */}
      <motion.div
        initial={{ width: '100%' }}
        animate={{ width: '0%' }}
        transition={{ duration: 4, ease: 'linear' }}
        className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-500"
      />

      <div className="mt-0.5 text-emerald-400 flex-shrink-0">
        <CheckCircle className="w-5 h-5 text-emerald-400" />
      </div>

      <div className="flex-1 min-w-0 pr-4">
        <p className="text-xs font-bold text-emerald-300 font-sans tracking-wide uppercase flex items-center gap-1.5">
          <Database className="w-3.5 h-3.5 text-emerald-400" />
          <span>Offline Sync Complete</span>
        </p>
        <p className="text-xs text-slate-200 mt-1 font-medium font-sans leading-relaxed">
          {toast.message}
        </p>
      </div>

      <button
        onClick={() => onRemove(toast.id)}
        className="text-slate-400 hover:text-white transition p-1 rounded-lg hover:bg-slate-800 flex-shrink-0"
      >
        <X className="w-4 h-4" />
      </button>
    </motion.div>
  );
};
