import React from 'react';
import { HospitalInfo } from '../types';
import { Activity, Stethoscope, Building2, Wallet, Settings, Lock, Unlock, FileSpreadsheet } from 'lucide-react';

interface NavbarProps {
  hospitalInfo: HospitalInfo;
  activeTab: 'billing' | 'hospital' | 'accounts' | 'settings';
  setActiveTab: (tab: 'billing' | 'hospital' | 'accounts' | 'settings') => void;
  isAdminUnlocked: boolean;
  setIsAdminUnlocked: (val: boolean) => void;
  onExportExcel: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  hospitalInfo,
  activeTab,
  setActiveTab,
  isAdminUnlocked,
  setIsAdminUnlocked,
  onExportExcel,
}) => {
  return (
    <header className="bg-emerald-900 text-white shadow-lg sticky top-0 z-40 border-b border-emerald-700">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-col md:flex-row justify-between items-center gap-2 border-b border-emerald-800/60">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-white/10 rounded-xl border border-white/20 shadow-inner">
            <Activity className="w-8 h-8 text-emerald-300 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white font-serif">
              {hospitalInfo.name}
            </h1>
            <p className="text-xs text-emerald-200 font-sans tracking-wide">
              {hospitalInfo.address} | Phone: <span className="font-mono font-semibold">{hospitalInfo.phone}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onExportExcel}
            className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs sm:text-sm font-medium rounded-lg shadow transition border border-emerald-400/30 cursor-pointer"
            title="Download all ledger data as .xls"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>Excel Download (.xls)</span>
          </button>

          <button
            onClick={() => setIsAdminUnlocked(!isAdminUnlocked)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold tracking-wider transition shadow cursor-pointer ${
              isAdminUnlocked
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-red-600/80 text-white border border-red-400/40 hover:bg-red-500'
            }`}
          >
            {isAdminUnlocked ? (
              <>
                <Unlock className="w-4 h-4 text-amber-300" />
                <span>Admin Unlocked</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4 text-white" />
                <span>Admin Locked</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Navigation Flowchart Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center justify-between sm:justify-start gap-1 sm:gap-4 overflow-x-auto py-2 scrollbar-none">
          <button
            onClick={() => setActiveTab('billing')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-medium text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'billing'
                ? 'bg-white text-emerald-950 shadow-md font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/80'
            }`}
          >
            <Stethoscope className={`w-4 h-4 ${activeTab === 'billing' ? 'text-emerald-700' : ''}`} />
            <span>Diagnostic Billing</span>
          </button>

          <button
            onClick={() => setActiveTab('hospital')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-medium text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'hospital'
                ? 'bg-white text-emerald-950 shadow-md font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/80'
            }`}
          >
            <Building2 className={`w-4 h-4 ${activeTab === 'hospital' ? 'text-emerald-700' : ''}`} />
            <span>Hospital Management</span>
          </button>

          <button
            onClick={() => setActiveTab('accounts')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-medium text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'accounts'
                ? 'bg-white text-emerald-950 shadow-md font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/80'
            }`}
          >
            <Wallet className={`w-4 h-4 ${activeTab === 'accounts' ? 'text-emerald-700' : ''}`} />
            <span>Accounts & Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-medium text-xs sm:text-sm transition-all whitespace-nowrap cursor-pointer relative ${
              activeTab === 'settings'
                ? 'bg-white text-emerald-950 shadow-md font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/80'
            }`}
          >
            <Settings className={`w-4 h-4 ${activeTab === 'settings' ? 'text-emerald-700' : ''}`} />
            <span>Settings & Security</span>
            {!isAdminUnlocked && (
              <span className="w-2 h-2 rounded-full bg-red-400 absolute top-2 right-2 animate-ping" />
            )}
          </button>
        </nav>
      </div>
    </header>
  );
};
