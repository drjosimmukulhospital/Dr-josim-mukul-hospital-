import React, { useState, useMemo } from 'react';
import { Bed, AdmittedPatient, Doctor, HospitalInfo } from '../types';
import { Building2, UserPlus, Printer, LogOut, Bed as BedIcon, CheckCircle2, AlertCircle, Calendar, Phone, DollarSign, Search, Filter, FileText, X } from 'lucide-react';
import { exportToExcel } from '../utils/excelExport';

interface HospitalManagementProps {
  beds: Bed[];
  admissions: AdmittedPatient[];
  doctors: Doctor[];
  hospitalInfo: HospitalInfo;
  onAdmitPatient: (patient: AdmittedPatient, bedId: string) => void;
  onDischargePatient: (patientId: string, finalBill: number) => void;
}

export const HospitalManagementView: React.FC<HospitalManagementProps> = ({
  beds,
  admissions,
  doctors,
  hospitalInfo,
  onAdmitPatient,
  onDischargePatient,
}) => {
  const [subTab, setSubTab] = useState<'admit' | 'beds' | 'admitted_list' | 'discharge'>('admit');

  // Admission Form State
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Child'>('Male');
  const [phone, setPhone] = useState('');
  const [guardianName, setGuardianName] = useState('');
  const [address, setAddress] = useState('');
  const [admittingDoctor, setAdmittingDoctor] = useState(doctors[0]?.name || '');
  const [selectedBedId, setSelectedBedId] = useState('');
  const [advancePaid, setAdvancePaid] = useState(3000);

  // Printable Form State
  const [printingAdmission, setPrintingAdmission] = useState<AdmittedPatient | null>(null);

  // Discharge Settlement Modal
  const [settlingPatient, setSettlingPatient] = useState<AdmittedPatient | null>(null);
  const [discountOnDischarge, setDiscountOnDischarge] = useState(0);

  // Search Filter
  const [searchQuery, setSearchQuery] = useState('');

  // Available Beds
  const availableBeds = useMemo(() => {
    return beds.filter((b) => !b.isOccupied);
  }, [beds]);

  // Handle Admission Submit
  const handleAdmissionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) {
      alert('Please enter patient name');
      return;
    }
    if (!selectedBedId) {
      alert('Please select an available bed or cabin');
      return;
    }

    const bed = beds.find((b) => b.id === selectedBedId);
    if (!bed) return;

    const newRegNo = `REG-2026-${Date.now().toString().slice(-4)}`;
    const nowStr = new Date().toISOString();

    const newAdmit: AdmittedPatient = {
      id: `adm-${Date.now()}`,
      regNo: newRegNo,
      patientName,
      age: age ? `${age} Years` : 'N/A',
      gender,
      phone: phone || 'N/A',
      guardianName: guardianName || 'N/A',
      address: address || 'Galachipa, Patuakhali',
      admittingDoctor: admittingDoctor || doctors[0]?.name || 'Self',
      bedId: bed.id,
      bedName: bed.name,
      bedType: bed.type,
      dailyRate: bed.dailyRate,
      admissionDate: nowStr,
      status: 'Admitted',
      advancePaid: Number(advancePaid) || 0,
      serviceCharges: 500,
      medicineCharges: 0,
      doctorVisitCharges: 1000,
      discount: 0,
    };

    onAdmitPatient(newAdmit, bed.id);
    setPrintingAdmission(newAdmit);

    // Reset Form
    setPatientName('');
    setAge('');
    setPhone('');
    setGuardianName('');
    setAddress('');
    setSelectedBedId('');
  };

  // Filtered Admissions List
  const activeAdmissions = useMemo(() => {
    return admissions
      .filter((a) => a.status === 'Admitted')
      .filter((a) => a.patientName.toLowerCase().includes(searchQuery.toLowerCase()) || a.regNo.toLowerCase().includes(searchQuery.toLowerCase()) || a.bedName.includes(searchQuery));
  }, [admissions, searchQuery]);

  // Export Beds & Admissions to Excel
  const exportAdmissionsExcel = () => {
    let rowsHtml = '';
    activeAdmissions.forEach((a, idx) => {
      const days = Math.max(1, Math.ceil((Date.now() - new Date(a.admissionDate).getTime()) / (1000 * 3600 * 24)));
      const bedRent = days * a.dailyRate;
      const totalEstimated = bedRent + a.serviceCharges + a.medicineCharges + a.doctorVisitCharges - a.discount;
      rowsHtml += `
        <tr>
          <td style="text-align: center;">${idx + 1}</td>
          <td>${a.regNo}</td>
          <td>${a.patientName} (${a.age})</td>
          <td>${a.guardianName} | ${a.phone}</td>
          <td>${a.bedName} (${a.bedType})</td>
          <td>${new Date(a.admissionDate).toLocaleDateString()} (${days} days)</td>
          <td style="text-align: right;">${a.advancePaid} BDT</td>
          <td style="text-align: right; font-weight: bold;">${totalEstimated} BDT</td>
        </tr>
      `;
    });

    const html = `
      <div style="text-align: center; margin-bottom: 20px;">
        <h2>${hospitalInfo.name}</h2>
        <p>${hospitalInfo.address}</p>
        <h3>Admitted Patients & Wards Census Report</h3>
      </div>
      <table border="1" cellspacing="0" cellpadding="6">
        <thead>
          <tr style="background-color: #0f766e; color: white;">
            <th>Sl. No</th>
            <th>Reg No</th>
            <th>Patient Name</th>
            <th>Guardian & Phone</th>
            <th>Bed / Cabin No</th>
            <th>Admission Date</th>
            <th>Advance Paid</th>
            <th>Estimated Gross Bill</th>
          </tr>
        </thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    `;
    exportToExcel(`Admitted_Patients_List_${new Date().toISOString().split('T')[0]}`, html);
  };

  return (
    <div className="space-y-6">
      {/* Flowchart Sub Navigation */}
      <div className="bg-white p-2 rounded-xl shadow-sm border border-slate-200 flex flex-wrap gap-2">
        <button
          onClick={() => setSubTab('admit')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'admit'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>Patient Admission Form</span>
        </button>

        <button
          onClick={() => setSubTab('admitted_list')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'admitted_list'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Admitted Patients List ({activeAdmissions.length})</span>
        </button>

        <button
          onClick={() => setSubTab('beds')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'beds'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <BedIcon className="w-4 h-4" />
          <span>Beds & Cabins Status ({beds.length})</span>
        </button>

        <button
          onClick={() => setSubTab('discharge')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-xs sm:text-sm transition cursor-pointer ${
            subTab === 'discharge'
              ? 'bg-emerald-700 text-white shadow'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
          }`}
        >
          <LogOut className="w-4 h-4" />
          <span>Discharge & Bill Settlement</span>
        </button>
      </div>

      {/* NODE 1: PATIENT ADMISSION FORM */}
      {subTab === 'admit' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-6">
            <div className="border-b border-slate-200 pb-4">
              <h2 className="text-lg font-bold text-slate-800 font-serif flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-emerald-600" />
                <span>Hospital Patient Admission Form</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">Fill out registration details and allocate available beds/cabins</p>
            </div>

            <form onSubmit={handleAdmissionSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Patient Name *</label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="e.g. Abdul Malek"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 focus:bg-white transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Age</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    placeholder="e.g. 60"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-emerald-600 focus:bg-white transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e: any) => setGender(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Child">Child</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Number</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="017xxxxxxxx"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Guardian's Name</label>
                  <input
                    type="text"
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    placeholder="Spouse / Father / Son"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Address</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Village, Thana, District"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Admitting Consultant / Doctor</label>
                  <select
                    value={admittingDoctor}
                    onChange={(e) => setAdmittingDoctor(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.name}>{d.name} ({d.specialty})</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Bed Selection & Advance Payment */}
              <div className="bg-emerald-50/70 p-4 rounded-xl border border-emerald-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-emerald-900 mb-1">Select Bed or Cabin *</label>
                  <select
                    required
                    value={selectedBedId}
                    onChange={(e) => setSelectedBedId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border-2 border-emerald-500 rounded-lg text-xs font-bold text-emerald-950 focus:outline-none"
                  >
                    <option value="">-- Select Available Bed ({availableBeds.length}) --</option>
                    {availableBeds.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.type}) - Daily Rate: {b.dailyRate} BDT
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-emerald-900 mb-1">Admission Advance Payment</label>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min={0}
                      value={advancePaid}
                      onChange={(e) => setAdvancePaid(Number(e.target.value) || 0)}
                      className="w-full px-3 py-2 bg-white border border-emerald-400 rounded-lg font-mono text-sm font-bold text-emerald-900 focus:outline-none"
                    />
                    <span className="font-bold text-emerald-800">BDT</span>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-lg transition flex items-center justify-center gap-2 cursor-pointer mt-4"
              >
                <UserPlus className="w-5 h-5" />
                <span>Complete Admission & Print Admission Sheet</span>
              </button>
            </form>
          </div>

          {/* Available Beds Quick Glance */}
          <div className="lg:col-span-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
            <h3 className="text-base font-bold text-slate-800 font-serif border-b pb-3 flex justify-between">
              <span>Available Beds & Cabins</span>
              <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">{availableBeds.length} Available</span>
            </h3>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {availableBeds.map((b) => (
                <div
                  key={b.id}
                  onClick={() => setSelectedBedId(b.id)}
                  className={`p-3 rounded-xl border transition cursor-pointer flex justify-between items-center ${
                    selectedBedId === b.id
                      ? 'bg-emerald-100 border-emerald-600 shadow-2xs font-bold'
                      : 'bg-slate-50 hover:bg-emerald-50/50 border-slate-200'
                  }`}
                >
                  <div>
                    <p className="text-xs font-bold text-slate-800">{b.name}</p>
                    <span className="text-[10px] text-slate-500">{b.type}</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {b.dailyRate} BDT/Day
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* NODE 2: ADMITTED PATIENTS LIST & PRINT FORM */}
      {subTab === 'admitted_list' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800 font-serif">Admitted Patients List</h2>
              <p className="text-xs text-slate-500">Currently admitted in-patients directory and registration sheets</p>
            </div>

            <div className="flex gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Reg No or Patient Name..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs"
                />
              </div>
              <button
                onClick={exportAdmissionsExcel}
                className="px-3.5 py-2 bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold cursor-pointer whitespace-nowrap"
              >
                Export Excel
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <th className="p-3">Reg No</th>
                  <th className="p-3">Patient Name & Age</th>
                  <th className="p-3">Guardian & Phone</th>
                  <th className="p-3">Bed / Cabin</th>
                  <th className="p-3">Admission Date</th>
                  <th className="p-3 text-right">Advance Paid</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeAdmissions.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-mono font-bold text-emerald-800">{a.regNo}</td>
                    <td className="p-3">
                      <div className="font-bold text-slate-800">{a.patientName}</div>
                      <div className="text-[11px] text-slate-500">{a.age}, {a.gender}</div>
                    </td>
                    <td className="p-3">
                      <div>{a.guardianName}</div>
                      <div className="text-[11px] font-mono text-slate-500">{a.phone}</div>
                    </td>
                    <td className="p-3">
                      <span className="font-bold text-slate-800">{a.bedName}</span>
                      <div className="text-[10px] text-emerald-700 font-mono">{a.dailyRate} BDT/Day ({a.bedType})</div>
                    </td>
                    <td className="p-3">{new Date(a.admissionDate).toLocaleDateString()}</td>
                    <td className="p-3 text-right font-mono font-bold text-emerald-700">{a.advancePaid} BDT</td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => setPrintingAdmission(a)}
                        className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg flex items-center gap-1 mx-auto text-xs font-semibold shadow-2xs cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Sheet</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* NODE 3: BEDS & CABINS STATUS FULL GRID */}
      {subTab === 'beds' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div className="flex justify-between items-center border-b pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800 font-serif">Beds & Wards Management</h2>
              <p className="text-xs text-slate-500">Real-time status updates of General Ward, Private Cabins, and ICU beds</p>
            </div>
            <div className="flex gap-3 text-xs font-semibold">
              <span className="flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block" /> Available ({availableBeds.length})
              </span>
              <span className="flex items-center gap-1 text-red-700 bg-red-50 px-2.5 py-1 rounded-lg border border-red-200">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" /> Occupied ({beds.length - availableBeds.length})
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {beds.map((b) => (
              <div
                key={b.id}
                className={`p-4 rounded-2xl border-2 transition relative overflow-hidden flex flex-col justify-between ${
                  b.isOccupied
                    ? 'bg-red-50/50 border-red-300'
                    : 'bg-emerald-50/50 border-emerald-400 hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                        b.isOccupied ? 'bg-red-600 text-white' : 'bg-emerald-700 text-white'
                      }`}
                    >
                      {b.isOccupied ? 'Occupied' : 'Available'}
                    </span>
                    <span className="font-mono text-xs font-bold text-slate-700">{b.dailyRate} BDT/Day</span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-800 font-serif">{b.name}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">{b.type}</p>
                </div>

                {b.isOccupied && b.currentPatientName && (
                  <div className="mt-4 pt-3 border-t border-red-200 bg-white/80 p-2 rounded-xl text-xs">
                    <span className="text-slate-400 block text-[10px]">Current Patient:</span>
                    <span className="font-bold text-red-950 truncate block">{b.currentPatientName}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* NODE 4: DISCHARGE & BILL SETTLEMENT */}
      {subTab === 'discharge' && (
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
          <div className="border-b pb-4">
            <h2 className="text-lg font-bold text-slate-800 font-serif">Patient Discharge & Bill Settlement</h2>
            <p className="text-xs text-slate-500">Calculate bed rent, service charges, doctor visits and pharmacies to generate discharge sheets</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeAdmissions.map((a) => {
              const days = Math.max(1, Math.ceil((Date.now() - new Date(a.admissionDate).getTime()) / (1000 * 3600 * 24)));
              const bedRent = days * a.dailyRate;
              const subTotalBill = bedRent + a.serviceCharges + a.medicineCharges + a.doctorVisitCharges;
              const estimatedDue = Math.max(0, subTotalBill - a.advancePaid);

              return (
                <div key={a.id} className="p-5 bg-slate-50 border border-slate-300 rounded-2xl space-y-3 flex flex-col justify-between shadow-2xs">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-mono font-bold text-emerald-800 text-xs bg-emerald-100 px-2 py-0.5 rounded">{a.regNo}</span>
                      <span className="text-xs font-mono font-bold">{days} Days Admitted</span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 font-serif">{a.patientName} ({a.age})</h3>
                    <p className="text-xs text-slate-500">{a.bedName} ({a.bedType})</p>
                    <p className="text-xs text-slate-600 mt-1">Doctor: {a.admittingDoctor}</p>
                  </div>

                  <div className="bg-white p-3 rounded-xl border border-slate-200 text-xs space-y-1">
                    <div className="flex justify-between"><span>Bed Rent ({days}x{a.dailyRate}):</span> <span className="font-mono font-bold">{bedRent} BDT</span></div>
                    <div className="flex justify-between"><span>Service & Doctor Visits:</span> <span className="font-mono">{a.serviceCharges + a.doctorVisitCharges} BDT</span></div>
                    <div className="flex justify-between"><span>Medicines & Pharmacy:</span> <span className="font-mono">{a.medicineCharges} BDT</span></div>
                    <div className="flex justify-between font-bold border-t pt-1 text-slate-800"><span>Total Gross Bill:</span> <span className="font-mono">{subTotalBill} BDT</span></div>
                    <div className="flex justify-between text-emerald-700 font-semibold"><span>Advance Paid:</span> <span className="font-mono">-{a.advancePaid} BDT</span></div>
                    <div className="flex justify-between text-red-600 font-bold text-sm border-t pt-1">
                      <span>Due Amount Payable:</span>
                      <span className="font-mono">{estimatedDue} BDT</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setSettlingPatient(a);
                      setDiscountOnDischarge(a.discount || 0);
                    }}
                    className="w-full py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow transition text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Settle Bill & Discharge</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* DISCHARGE BILL SETTLEMENT MODAL */}
      {settlingPatient && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-300">
            <div className="bg-gradient-to-r from-red-800 to-rose-900 p-5 text-white flex justify-between items-center">
              <div>
                <h3 className="font-bold font-serif text-lg">Final Bill & Discharge Summary</h3>
                <p className="text-xs text-red-200">{settlingPatient.patientName} ({settlingPatient.regNo})</p>
              </div>
              <button onClick={() => setSettlingPatient(null)} className="text-white/80 hover:text-white"><X className="w-6 h-6" /></button>
            </div>

            <div className="p-6 space-y-4 text-xs text-slate-800 font-sans">
              {(() => {
                const days = Math.max(1, Math.ceil((Date.now() - new Date(settlingPatient.admissionDate).getTime()) / (1000 * 3600 * 24)));
                const bedRent = days * settlingPatient.dailyRate;
                const totalGross = bedRent + settlingPatient.serviceCharges + settlingPatient.medicineCharges + settlingPatient.doctorVisitCharges;
                const netBill = Math.max(0, totalGross - (discountOnDischarge || 0));
                const finalPayable = Math.max(0, netBill - settlingPatient.advancePaid);

                return (
                  <>
                    <div className="space-y-2 bg-slate-50 p-4 rounded-xl border border-slate-200 text-sm">
                      <div className="flex justify-between"><span>Bed Rent ({days} Days):</span> <span className="font-mono font-bold">{bedRent} BDT</span></div>
                      <div className="flex justify-between"><span>Service & Doctor Visits:</span> <span className="font-mono">{settlingPatient.serviceCharges + settlingPatient.doctorVisitCharges} BDT</span></div>
                      <div className="flex justify-between"><span>Medicines & Wards:</span> <span className="font-mono">{settlingPatient.medicineCharges} BDT</span></div>
                      <div className="flex justify-between font-bold border-t pt-2 text-slate-900 text-base">
                        <span>Total Gross Bill:</span>
                        <span className="font-mono">{totalGross} BDT</span>
                      </div>

                      <div className="flex justify-between items-center pt-1">
                        <span>Discharge Discount:</span>
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min={0}
                            max={totalGross}
                            value={discountOnDischarge || ''}
                            onChange={(e) => setDiscountOnDischarge(Number(e.target.value) || 0)}
                            className="w-20 px-2 py-1 bg-white border border-slate-300 rounded text-right font-mono"
                          />
                          <span>BDT</span>
                        </div>
                      </div>

                      <div className="flex justify-between text-emerald-800 font-bold">
                        <span>Advance Deposited:</span>
                        <span className="font-mono">-{settlingPatient.advancePaid} BDT</span>
                      </div>

                      <div className="flex justify-between bg-red-100 p-2.5 rounded-lg border border-red-300 text-red-900 font-bold text-base mt-3">
                        <span>Net Amount Payable:</span>
                        <span className="font-mono">{finalPayable} BDT</span>
                      </div>
                    </div>

                    <div className="flex gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setSettlingPatient(null)}
                        className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onDischargePatient(settlingPatient.id, netBill);
                          setSettlingPatient(null);
                        }}
                        className="flex-1 py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl shadow transition text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Confirm Discharge</span>
                      </button>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* PRINT ADMISSION FORM MODAL */}
      {printingAdmission && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-300 flex flex-col max-h-[90vh]">
            <div id="admission-print-area" className="p-6 overflow-y-auto space-y-4 font-sans text-slate-800 text-xs">
              <div className="text-center border-b border-slate-300 pb-4">
                <h2 className="text-lg font-bold font-serif text-emerald-900">{hospitalInfo.name}</h2>
                <p className="text-[11px] text-slate-600">{hospitalInfo.address}</p>
                <p className="text-[11px] font-mono">Emergency Hotline: {hospitalInfo.phone}</p>
                <div className="mt-2 inline-block bg-emerald-800 text-white px-3 py-0.5 rounded text-[11px] font-bold tracking-wider uppercase">
                  Patient Admission Sheet
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div><span className="font-semibold">Reg Number:</span> <span className="font-mono font-bold text-emerald-900">{printingAdmission.regNo}</span></div>
                <div><span className="font-semibold">Admission Date:</span> {new Date(printingAdmission.admissionDate).toLocaleString()}</div>
                <div className="col-span-2"><span className="font-semibold">Patient Name:</span> <span className="font-bold text-sm text-slate-900">{printingAdmission.patientName}</span></div>
                <div><span className="font-semibold">Age & Gender:</span> {printingAdmission.age}, {printingAdmission.gender}</div>
                <div><span className="font-semibold">Mobile:</span> <span className="font-mono">{printingAdmission.phone}</span></div>
                <div className="col-span-2"><span className="font-semibold">Guardian:</span> {printingAdmission.guardianName}</div>
                <div className="col-span-2"><span className="font-semibold">Address:</span> {printingAdmission.address}</div>
                <div className="col-span-2 border-t pt-2 mt-1"><span className="font-semibold">Admitting Consultant:</span> <span className="font-bold text-emerald-800">{printingAdmission.admittingDoctor}</span></div>
                <div><span className="font-semibold">Bed / Cabin:</span> <span className="font-bold">{printingAdmission.bedName}</span></div>
                <div><span className="font-semibold">Daily Rate:</span> <span className="font-mono font-bold">{printingAdmission.dailyRate} BDT</span></div>
                <div className="col-span-2 bg-emerald-100 p-2 rounded text-emerald-950 font-bold text-center mt-2">
                  Admission Advance Paid Receipt: {printingAdmission.advancePaid} BDT
                </div>
              </div>

              <div className="pt-10 flex justify-between text-[10px] text-slate-500 text-center">
                <div className="border-t border-slate-400 pt-1 px-4">Patient / Guardian Signature</div>
                <div className="border-t border-slate-400 pt-1 px-4">Admission Officer / Duty Doctor</div>
              </div>
            </div>

            <div className="bg-slate-100 p-4 border-t border-slate-200 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setPrintingAdmission(null)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="px-5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl shadow transition text-xs flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
