import { HospitalInfo, DiagnosticTest, Doctor, PatientBill, Bed, AdmittedPatient, AccountTransaction } from '../types';

export const initialHospitalInfo: HospitalInfo = {
  name: "Dr. Josim Mukul Hospital & Diagnostic Centre",
  address: "V.I.P Road, Galachipa, Patuakhali.",
  phone: "01312-049981",
  email: "info@josimmukulhospital.com",
  slogan: "Accurate Diagnosis & Trusted Healthcare"
};

export const initialTests: DiagnosticTest[] = [
  // Pathology
  { id: 't1', code: 'PATH-01', name: 'CBC (Complete Blood Count)', category: 'Pathology', price: 450, normalRange: 'Hb: 12-16 g/dL, WBC: 4000-11000', roomNo: '102' },
  { id: 't2', code: 'PATH-02', name: 'Blood Grouping & Rh Factor', category: 'Pathology', price: 150, roomNo: '102' },
  { id: 't3', code: 'PATH-03', name: 'RBS (Random Blood Sugar)', category: 'Pathology', price: 120, normalRange: '3.9 - 7.8 mmol/L', roomNo: '102' },
  { id: 't4', code: 'PATH-04', name: 'FBS (Fasting Blood Sugar)', category: 'Pathology', price: 150, normalRange: '3.9 - 5.5 mmol/L', roomNo: '102' },
  { id: 't5', code: 'PATH-05', name: 'HbA1c', category: 'Pathology', price: 900, normalRange: '< 5.7%', roomNo: '102' },
  { id: 't6', code: 'PATH-06', name: 'Lipid Profile Full', category: 'Biochemistry', price: 1200, normalRange: 'Chol < 200 mg/dL', roomNo: '103' },
  { id: 't7', code: 'PATH-07', name: 'Serum Creatinine', category: 'Biochemistry', price: 350, normalRange: '0.6 - 1.2 mg/dL', roomNo: '103' },
  { id: 't8', code: 'PATH-08', name: 'Serum Bilirubin (Total)', category: 'Biochemistry', price: 300, normalRange: '0.2 - 1.2 mg/dL', roomNo: '103' },
  { id: 't9', code: 'PATH-09', name: 'SGPT / ALT', category: 'Biochemistry', price: 400, normalRange: 'Upto 40 U/L', roomNo: '103' },
  { id: 't10', code: 'PATH-10', name: 'SGOT / AST', category: 'Biochemistry', price: 400, normalRange: 'Upto 40 U/L', roomNo: '103' },
  { id: 't11', code: 'PATH-11', name: 'Serum Electrolytes (Na, K, Cl)', category: 'Biochemistry', price: 950, roomNo: '103' },
  { id: 't12', code: 'PATH-12', name: 'Urine R/E (Routine Examination)', category: 'Pathology', price: 200, roomNo: '102' },
  { id: 't13', code: 'PATH-13', name: 'Stool R/E', category: 'Pathology', price: 200, roomNo: '102' },
  { id: 't14', code: 'PATH-14', name: 'HBsAg (Screening)', category: 'Pathology', price: 400, normalRange: 'Negative', roomNo: '102' },
  { id: 't15', code: 'PATH-15', name: 'Dengue NS1 Antigen', category: 'Pathology', price: 650, normalRange: 'Negative', roomNo: '102' },
  { id: 't16', code: 'PATH-16', name: 'Dengue Antibody (IgG & IgM)', category: 'Pathology', price: 800, normalRange: 'Negative', roomNo: '102' },
  { id: 't17', code: 'PATH-17', name: 'Widal Test', category: 'Pathology', price: 350, roomNo: '102' },
  { id: 't18', code: 'PATH-18', name: 'TSH (Thyroid Stimulating Hormone)', category: 'Biochemistry', price: 850, normalRange: '0.4 - 4.0 mIU/L', roomNo: '103' },
  { id: 't19', code: 'PATH-19', name: 'Serum Uric Acid', category: 'Biochemistry', price: 350, normalRange: '3.4 - 7.0 mg/dL', roomNo: '103' },
  { id: 't20', code: 'PATH-20', name: 'Troponin-I', category: 'Cardiology', price: 1200, normalRange: '< 0.04 ng/mL', roomNo: '105' },

  // Radiology
  { id: 't21', code: 'RAD-01', name: 'Digital X-Ray Chest P/A View', category: 'Radiology', price: 500, roomNo: '201' },
  { id: 't22', code: 'RAD-02', name: 'Digital X-Ray KUB View', category: 'Radiology', price: 600, roomNo: '201' },
  { id: 't23', code: 'RAD-03', name: 'Digital X-Ray Cervical Spine B/V', category: 'Radiology', price: 800, roomNo: '201' },
  { id: 't24', code: 'RAD-04', name: 'Digital X-Ray LS Spine B/V', category: 'Radiology', price: 800, roomNo: '201' },

  // Ultrasound
  { id: 't25', code: 'USG-01', name: 'USG of Whole Abdomen', category: 'Ultrasound', price: 900, roomNo: '202' },
  { id: 't26', code: 'USG-02', name: 'USG of Lower Abdomen / Pelvis', category: 'Ultrasound', price: 700, roomNo: '202' },
  { id: 't27', code: 'USG-03', name: 'USG of Pregnancy Profile (Anomaly)', category: 'Ultrasound', price: 1200, roomNo: '202' },
  { id: 't28', code: 'USG-04', name: 'USG of KUB & Prostate', category: 'Ultrasound', price: 800, roomNo: '202' },

  // Cardiology
  { id: 't29', code: 'CARD-01', name: 'ECG (Computerized 12 Channel)', category: 'Cardiology', price: 400, roomNo: '105' },
  { id: 't30', code: 'CARD-02', name: 'Echocardiography (2D & Color Doppler)', category: 'Cardiology', price: 2200, roomNo: '105' },
];

export const initialDoctors: Doctor[] = [
  { id: 'd1', name: 'Dr. Md. Josim Uddin', degree: 'MBBS, BCS (Health), FCPS (Medicine)', specialty: 'Medicine & Chest Disease Specialist', phone: '01711-112233', commissionRate: 35 },
  { id: 'd2', name: 'Dr. AKM Mukul Hossain', degree: 'MBBS, D-Card, MD (Cardiology)', specialty: 'Cardiology & Medicine Specialist', phone: '01811-223344', commissionRate: 40 },
  { id: 'd3', name: 'Dr. Salma Akter Shiuly', degree: 'MBBS, DGO (DU)', specialty: 'Gynecology & Obstetrics Specialist', phone: '01911-334455', commissionRate: 30 },
  { id: 'd4', name: 'Dr. Kamrul Hassan Shikdar', degree: 'MBBS, D-Ortho, MS (Orthopedics)', specialty: 'Bone, Joint & Trauma Surgeon', phone: '01611-445566', commissionRate: 30 },
  { id: 'd5', name: 'Dr. Tania Rahman', degree: 'MBBS, FCPS (Pediatrics)', specialty: 'Neonatal & Pediatric Specialist', phone: '01511-556677', commissionRate: 35 },
  { id: 'd6', name: 'Self / Hospital Default', degree: 'Non-Referral', specialty: 'Direct Patient', phone: 'N/A', commissionRate: 0 },
];

export const initialBeds: Bed[] = [
  { id: 'b1', name: 'General Bed-01 (Male)', type: 'General Ward', dailyRate: 500, isOccupied: true, currentPatientName: 'Abdul Malek', currentPatientId: 'p-101' },
  { id: 'b2', name: 'General Bed-02 (Male)', type: 'General Ward', dailyRate: 500, isOccupied: false },
  { id: 'b3', name: 'General Bed-03 (Female)', type: 'General Ward', dailyRate: 500, isOccupied: true, currentPatientName: 'Rabeya Khatun', currentPatientId: 'p-102' },
  { id: 'b4', name: 'General Bed-04 (Female)', type: 'General Ward', dailyRate: 500, isOccupied: false },
  { id: 'b5', name: 'Cabin-101 (Non-AC Single)', type: 'Cabin (Non-AC)', dailyRate: 1200, isOccupied: false },
  { id: 'b6', name: 'Cabin-102 (Non-AC Double)', type: 'Cabin (Non-AC)', dailyRate: 1500, isOccupied: true, currentPatientName: 'Mokhlesur Rahman', currentPatientId: 'p-103' },
  { id: 'b7', name: 'VIP Cabin-201 (AC)', type: 'Cabin (AC)', dailyRate: 2500, isOccupied: false },
  { id: 'b8', name: 'VIP Cabin-202 (AC)', type: 'Cabin (AC)', dailyRate: 2500, isOccupied: false },
  { id: 'b9', name: 'ICU Bed-01', type: 'ICU', dailyRate: 6000, isOccupied: false },
  { id: 'b10', name: 'Post Operative Bed-01', type: 'CCU', dailyRate: 3500, isOccupied: false },
];

const todayStr = new Date().toISOString().split('T')[0];

export const initialBills: PatientBill[] = [
  {
    id: 'bill-1001',
    receiptNo: 'INV-2026-1001',
    patientName: 'Mostofa Kamal',
    age: '42 Years',
    gender: 'Male',
    phone: '01722-334455',
    refDoctorId: 'd1',
    refDoctorName: 'Dr. Md. Josim Uddin',
    tests: [
      { testId: 't1', code: 'PATH-01', name: 'CBC (Complete Blood Count)', price: 450, discount: 0 },
      { testId: 't3', code: 'PATH-03', name: 'RBS (Random Blood Sugar)', price: 120, discount: 0 },
      { testId: 't21', code: 'RAD-01', name: 'Digital X-Ray Chest P/A View', price: 500, discount: 50 }
    ],
    subTotal: 1070,
    discountAmount: 50,
    netTotal: 1020,
    paidAmount: 1020,
    dueAmount: 0,
    paymentMethod: 'Cash',
    date: todayStr + 'T10:30:00Z',
    deliveryDate: todayStr + 'T17:00:00Z',
    status: 'Paid'
  },
  {
    id: 'bill-1002',
    receiptNo: 'INV-2026-1002',
    patientName: 'Najma Begum',
    age: '35 Years',
    gender: 'Female',
    phone: '01833-445566',
    refDoctorId: 'd3',
    refDoctorName: 'Dr. Salma Akter Shiuly',
    tests: [
      { testId: 't25', code: 'USG-01', name: 'USG of Whole Abdomen', price: 900, discount: 100 },
      { testId: 't12', code: 'PATH-12', name: 'Urine R/E (Routine Examination)', price: 200, discount: 0 }
    ],
    subTotal: 1100,
    discountAmount: 100,
    netTotal: 1000,
    paidAmount: 800,
    dueAmount: 200,
    paymentMethod: 'Cash',
    date: todayStr + 'T11:15:00Z',
    deliveryDate: todayStr + 'T18:00:00Z',
    status: 'Due'
  },
  {
    id: 'bill-1003',
    receiptNo: 'INV-2026-1003',
    patientName: 'Rahim Hawlader',
    age: '58 Years',
    gender: 'Male',
    phone: '01944-556677',
    refDoctorId: 'd2',
    refDoctorName: 'Dr. AKM Mukul Hossain',
    tests: [
      { testId: 't29', code: 'CARD-01', name: 'ECG (Computerized 12 Channel)', price: 400, discount: 0 },
      { testId: 't30', code: 'CARD-02', name: 'Echocardiography (2D & Color Doppler)', price: 2200, discount: 200 },
      { testId: 't6', code: 'PATH-06', name: 'Lipid Profile Full', price: 1200, discount: 0 }
    ],
    subTotal: 3800,
    discountAmount: 200,
    netTotal: 3600,
    paidAmount: 3600,
    dueAmount: 0,
    paymentMethod: 'Mobile Banking',
    date: todayStr + 'T12:00:00Z',
    deliveryDate: todayStr + 'T20:00:00Z',
    status: 'Paid'
  }
];

export const initialAdmissions: AdmittedPatient[] = [
  {
    id: 'p-101',
    regNo: 'REG-2026-001',
    patientName: 'Abdul Malek',
    age: '62 Years',
    gender: 'Male',
    phone: '01711-998877',
    guardianName: 'Hasan Malek (Son)',
    address: 'Galachipa Pourashava, Patuakhali',
    admittingDoctor: 'Dr. Md. Josim Uddin',
    bedId: 'b1',
    bedName: 'General Bed-01 (Male)',
    bedType: 'General Ward',
    dailyRate: 500,
    admissionDate: todayStr + 'T08:00:00Z',
    status: 'Admitted',
    advancePaid: 3000,
    serviceCharges: 500,
    medicineCharges: 1850,
    doctorVisitCharges: 1000,
    discount: 200
  },
  {
    id: 'p-102',
    regNo: 'REG-2026-002',
    patientName: 'Rabeya Khatun',
    age: '45 Years',
    gender: 'Female',
    phone: '01822-887766',
    guardianName: 'Kabir Hossain (Husband)',
    address: 'Amkhola, Galachipa',
    admittingDoctor: 'Dr. AKM Mukul Hossain',
    bedId: 'b3',
    bedName: 'General Bed-03 (Female)',
    bedType: 'General Ward',
    dailyRate: 500,
    admissionDate: todayStr + 'T09:30:00Z',
    status: 'Admitted',
    advancePaid: 2500,
    serviceCharges: 300,
    medicineCharges: 900,
    doctorVisitCharges: 800,
    discount: 0
  },
  {
    id: 'p-103',
    regNo: 'REG-2026-003',
    patientName: 'Mokhlesur Rahman',
    age: '54 Years',
    gender: 'Male',
    phone: '01933-776655',
    guardianName: 'Nurul Islam (Brother)',
    address: 'Dashmina, Patuakhali',
    admittingDoctor: 'Dr. Kamrul Hassan Shikdar',
    bedId: 'b6',
    bedName: 'Cabin-102 (Non-AC Double)',
    bedType: 'Cabin (Non-AC)',
    dailyRate: 1500,
    admissionDate: todayStr + 'T14:00:00Z',
    status: 'Admitted',
    advancePaid: 5000,
    serviceCharges: 1000,
    medicineCharges: 2400,
    doctorVisitCharges: 1500,
    discount: 500
  }
];

export const initialTransactions: AccountTransaction[] = [
  { id: 'tx-1', date: todayStr + 'T10:30:00Z', type: 'Income', category: 'Diagnostic Bill', description: 'Invoice INV-2026-1001 payment received (Mostofa Kamal)', amount: 1020, refId: 'bill-1001' },
  { id: 'tx-2', date: todayStr + 'T11:15:00Z', type: 'Income', category: 'Diagnostic Bill', description: 'Invoice INV-2026-1002 payment received (Najma Begum)', amount: 800, refId: 'bill-1002' },
  { id: 'tx-3', date: todayStr + 'T12:00:00Z', type: 'Income', category: 'Diagnostic Bill', description: 'Invoice INV-2026-1003 payment received (Rahim Hawlader)', amount: 3600, refId: 'bill-1003' },
  { id: 'tx-4', date: todayStr + 'T08:00:00Z', type: 'Income', category: 'Hospital Bill', description: 'Patient Abdul Malek admission advance deposit', amount: 3000, refId: 'p-101' },
  { id: 'tx-5', date: todayStr + 'T14:00:00Z', type: 'Income', category: 'Hospital Bill', description: 'Patient Mokhlesur Rahman cabin advance deposit', amount: 5000, refId: 'p-103' },
  { id: 'tx-6', date: todayStr + 'T15:00:00Z', type: 'Expense', category: 'Pharmacy', description: 'Emergency medicine & surgical items purchase (Medicine Corner)', amount: 4200 },
  { id: 'tx-7', date: todayStr + 'T16:00:00Z', type: 'Expense', category: 'Utility Bill', description: 'Generator fuel / diesel purchase (Rural electricity load shedding backup)', amount: 1800 },
];
